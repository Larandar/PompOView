
{"signature" : "{'documentDistance': 'sum', 'verbose': True, 'documentFilter': ['t', 's', 'el'], 'fileout': 'out.js', 'segmenter': ['nl', '1'], 'segmentDistance': 'lv', 'documentDistanceFilter': ['t', 'c', 'h', 'c', 't', 'c', 't']}",
 
 "filenames" : ['corpus_test/d1.py', 'corpus_test/d2.py'], 
 
 "corpus_scores" : [[0.0, 0.039809999999999998], [0.039809999999999998, 0.0]] 

}