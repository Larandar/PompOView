public function __construct($texte, $offset_list){
  $this->texte      = $texte;
  $this->offset_old = $offset_list ;
  for($i=0; $i<len(offset_list); ++$i){
    $this->genere();
  }
  return True;
}

public function test(){
  return $this->__construct();
}
