# -*- coding: cp1252 -*-
import zlib
import glob

# min, max ou "moy" /!\ "moy" � mettre entre guillemets, les autres non !!
PARAM_DENDO = max


def dendrogramme(m):
    # Cr�e le dictionnaire dendro dont la cl� est une cha�ne de caract�re (repr�sentant le dendogramme du groupe) et sa valeur une liste d'entier (les num�ros des docs)
    # De base, on remplit ce dictionnaire avec un groupe (= entr�e de dictionnaire) pour chaque document.
    dendro=dict()
    for t1, t2 in m:
        if t1 != t2:
            dendro[str(t1)]=[t1]
            dendro[str(t2)]=[t2]

    # Tant qu'on a pas r�duit le dendrogramme a un groupe unique, il faut fusionner les groupes...
    while len(dendro) >1:
        # Liste des groupes pour aider � parcourir les �l�ments du dendrogramme 
        listeCles=dendro.keys()
        # Liste des distances (entre 2 groupes)
        distanceMini= list()
        # On parcourt tous les groupes du dendrogramme
        for clestr in dendro:
            listeCles.remove(clestr)
            for clestr2 in listeCles:
                #print "Clestr: %s clestr2: %s"%(clestr, clestr2)
                distanceMini.append( (distanceGroupe(dendro[clestr],dendro[clestr2],m,PARAM_DENDO), clestr, clestr2) )
        mini= min(distanceMini)

        # Comparaison entre le 1er �lement du groupe et le dernier �lement de l'autre groupe (=>min1), et vice versa (=>min2).

        # 1er �lement de la liste dendro[mini[2]] compar� avec le dernier �lement de la liste dendro[mini[3]]
        if m.has_key((dendro[mini[1]][0],dendro[mini[2]][len(dendro[mini[2]])-1])):
            min1= m[(dendro[mini[1]][0],dendro[mini[2]][len(dendro[mini[2]])-1])]
        else:
            min1= m[(dendro[mini[2]][len(dendro[mini[2]])-1],dendro[mini[1]][0])]
        #min2=
        if m.has_key((dendro[mini[2]][0],dendro[mini[1]][len(dendro[mini[1]])-1])):
            min2= m[(dendro[mini[2]][0],dendro[mini[1]][len(dendro[mini[1]])-1])]
        else:
            min2= m[(dendro[mini[1]][len(dendro[mini[1]])-1],dendro[mini[2]][0])]
        #print min1
        #print min2
        #print "--------"

        if min1<=min2:
            dendro['('+mini[2]+','+mini[1]+')']=dendro[mini[2]]+dendro[mini[1]]
        else:
             dendro['('+mini[1]+','+mini[2]+')']=dendro[mini[1]]+dendro[mini[2]]   
        del dendro[mini[1]]
        del dendro[mini[2]]
    # retourne la chaine de caract�re repr�sentant le dendrogramme
    # print dendro
    return dendro.keys()[0]
        

def distance_info(text1, text2):
    #concat�nation des deux textes
    t12 = text1 + text2
    #taille du fichier compress� texte 1
    c_t1  = float(len(zlib.compress(text1, zlib.Z_BEST_COMPRESSION)))
    #taille du fichier compress� texte 2
    c_t2  = float(len(zlib.compress(text2, zlib.Z_BEST_COMPRESSION)))
    #taille du fichier concat�n� compress�
    c_t12 = float(len(zlib.compress(t12, zlib.Z_BEST_COMPRESSION)))
    
    #Calcul de la distance (tableau du cours)
    #Deux �l�ments � 0 sont indentique
    #Deux �l�ments � 1 sont diff�rent
    # max(c_t1, c_t2) normalise la taille de la distance
    distance =  1 - ((c_t1 + c_t2) - c_t12) / max(c_t1,c_t2)
    
    return distance


# Retourne la matrice des distances informatives entre chaque fichier du dossier dont le chemin est pass� en param�tre.
# @param le dossier contenant les fichiers .xml � analyser entre eux
# @return la matrice des distances entre les fichiers
def matrice_distance(adresse):
    #Produit une liste des adresse de tout les fichiers contenu � l'adresse donn�e en argument du programme
    l=glob.glob(adresse+"/*")
    listeNomFich=[]
    #print l
    # Matrice des distances (dictionnaire des distances):
    m={}
    # On ouvre chaque fichier du corpus d'une langue, on met son contenu dans t1, on compare la distance informative avec les autres (t2)
    for i, f1 in enumerate(l):
        listeNomFich.append(f1.replace(adresse, "").replace('\\', ''))
        f1= open(f1, 'r')
        t1= f1.read()
        f1.close()
        for j, f2 in enumerate(l):
            f2= open(f2, 'r')
            t2= f2.read()
            f2.close()
            if i == j:
                m[(i, j)] = 0
            elif i >j:    
                m[(i, j)] = distance_info(t1, t2)
    #print listeNomFich
    return m, listeNomFich


# 
#  #param gr1 gr2 des listes de docs � comparer
# @param param le parametre contenu dans PARAM_DENDO (min, max, moy)
def distanceGroupe(gr1, gr2, m, param):
    listeDist=list()
    
    for i in range(len(gr1)):
          for j in range(len(gr2)):
               if m.has_key((gr1[i], gr2[j])):
                    listeDist.append(m[(gr1[i], gr2[j])])
               else:
                    listeDist.append(m[(gr2[j], gr1[i])])
    if param == max or param == min:
        return param(listeDist)
    elif param == "moy":
        somme=0.0
        for val in listeDist:
            somme+=val
        return somme/len(listeDist)





#####----------------------------------------------------------------------------------------------#####
#####Fonctions pour le Tableau Colori�

def liste_ordonnee(den):
    den=den.replace("(", " ")
    den=den.replace(")", " ")
    den=den.replace(",", " ")
    lis_ord=den.split()
    return lis_ord


def tableau_html(lis, m, para, listeNomsFich):
    l_moy=moyenne(para, m)
    s='<table style="collapse:collapse;" cellspacing="0" ;border-collapse: collapse>\n'
    s+='<tr>\n'
    s+='<td>' + ' ' + '</td>\n'
    for i in lis:
        s+='<td>' + i + '</td>\n'
    s+='</tr>\n'
    c=0
    cf=len(lis)
    val=""
    while c < cf:
        s+='<tr>\n'
        s+='<td>' + lis[c] + '</td>\n'
        cl=0
        clf=len(lis)
        while cl < clf:
            if (int(lis[c]), int(lis[cl])) in m:
                val=str(m[int(lis[c]), int(lis[cl])])
                s+= str(colorier(float(val[:5]), l_moy))
            else:
                val=str(m[int(lis[cl]), int(lis[c])])
                s+= str(colorier(float(val[:5]), l_moy))
            cl+=1

        s+='</tr>\n\n'
        c+=1
    s+='</table>'
    s+="<ul>\n"
    for i in lis:
        s+="<li>" + i + " = " + listeNomsFich[int(i)] + "</li>\n"
    s+="<ul>\n"
    return s


def moyenne(para, m):
    l=[0, 1]
    l_temp=[0]
    c=0
    while c < para:
        c2=0
        while l_temp[-1] != l[-1]:
            l_temp+=[moyenne_part(m, l_temp[-1], l[c2+1]), l[c2+1]]
            c2+=1
        c+=1
        l=l_temp
        l_temp=[0]
    return l



def moyenne_part(m, val1, val2):
    somme=0
    nb=0
    for i in m:
        if m[i] > val1 and m[i] <= val2:
            somme+=m[i]
            nb+=1
    return somme/nb

def colorier(val, l):
    if val==0:
        return '<td style="font-size:11px;padding:3px;background-color:hsl(00, 100%, 50%);">' + str(val) + '</td>\n'
    else:
        c=0
        cf=len(l)-1
        while c < cf:
            if val > l[c] and val <= l[c+1]:
                return '<td style="font-size:11px;padding:3px;background-color:hsl(' + str(120./cf*(c+1)) + ', 100%, 50%);">' + str(val) + '</td>\n'
            else:
                c+=1
        print val
            



#####----------------------------------------------------------------------------------------------#####
#####Reprise anciens TP


# Cr�er un ent�te html en utf-8
def get_header_html() :
  s = '''
  <html>
    <head>
      <meta http-equiv="Content-Type"
            content="text/html; charset=utf-8">
      <title>Matrice des Distances</title>
    </head>
    <body>
  '''
  return s

# Cr�er le pied de page html
def get_footer_html() :
  s = '''
    </body>
  </html>
  '''
  return s

# ECRIRE S DANS UN FICHIER
def write_file(path_file, s) :
  f = open(path_file, 'w')
  f.write(s)
  f.close()
        
#####----------------------------------------------------------------------------------------------#####        
            
## Fonction principale
if __name__ == '__main__':  
    m, listeNomsFich= matrice_distance("./corpus/atp1-2")
    #print listeNomsFich
    den = dendrogramme(m)
    lis_ord = liste_ordonnee(den)
    txt_html=get_header_html()
    txt_html+=tableau_html(lis_ord, m, 4, listeNomsFich)
    txt_html+=get_footer_html()
    write_file("tableau.htm", txt_html)

