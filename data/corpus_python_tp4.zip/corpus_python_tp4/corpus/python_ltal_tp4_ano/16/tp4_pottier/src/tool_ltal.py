#!/usr/local/bin/pythonw
# -*- coding: utf-8 -*-

import re, string, htmlentitydefs

def ltuple2ul(l) :
  s = ''
  for t in l :
    i = ''
    for e in t :
      i += '%s '%(e)
    s += '<li>%s</li>'%(i)
  return '<ul>%s</ul>'%s

def list2ul(l) :
  s = ''
  for e in l :
    s += '<li>%s</li>'%(e)
  return '<ul>%s</ul>'%s

def dict2ul(d) :
  s = ''
  for k,e in d.iteritems() :
    s += '<li>%s :: %s</li>'%(str(k),str(e))
  return '<ul>%s</ul>'%s

def dict_count(d, k) :
  if(d.has_key(k)) :
    d[k] += 1
  else :
    d[k] = 1

def read_file(path_file) :
  f = open(path_file, 'r')
  s = f.read()
  f.close()
  return s

def write_file(path_file, s) :
  f = open(path_file, 'w')
  f.write(s)
  f.close()

def supp_val_dic(dic,val):
    res={}
    for key in dic:
        if dic[key] != val:
            res[key]=dic[key]
    return res

def supp_key_dic(dic,key):
    res={}
    for k in dic:
        if k != key:
            res[k]=dic[k]
    return res


def encoding2unicode(s, encoding) :
  return unicode(s, encoding)

def unicode2encoding(s, encoding) :
  return s.encode(encoding)
  
def double_match(match1, match2):
    encodingtemp = string.lower(match1.group(1))
    m = re.search(match2, encodingtemp)
    return m.group(1)

def source2encoding(s) :
  default_encoding = 'iso-8859-1'
  heT=u'http-equiv=["\']content-Type["\']'
  ctT=u'content=["\']text/html;'
  chrset=u'charset=(.*?)["\']'
  sep=u'[ \n\r]'
  heF=u'%s%s*'%(heT,sep)
  ctF=u'%s%s*%s%s*'%(ctT,sep,chrset,sep)
  pattern_detect_encoding1 = u'<meta%s+%s(%s)'%(sep,heF,ctF)
  pattern_detect_encoding2 = u'<meta%s+(%s)%s'%(sep,ctF,heF)
  pattern_compiled1 = re.compile(pattern_detect_encoding1, re.I)
  pattern_compiled2 = re.compile(pattern_detect_encoding2, re.I)
  match_charset1 = re.search(pattern_compiled1, s)
  match_charset2 = re.search(pattern_compiled2, s)
  if match_charset1 :
    encoding = double_match(match_charset1, chrset)
    #print 'detected charset ::', encoding.encode('utf-8')
  elif match_charset2 :
    encoding = double_match(match_charset2, chrset)
    #print 'detected charset ::', encoding.encode('utf-8')    
  else :
    encoding = default_encoding
    #print 'undetected charset, use default encoding ::', default_encoding
  return encoding

def color_string(s_unicode, substring, color) :
  print 'color string : %s'%(substring.encode('utf-8'))
  pattern1 = re.compile(u'%s'%(substring), re.I | re.M)
  replace = u'<span style="color:%s; background-color:grey;">%s</span>'%(color, substring)
  output = pattern1.sub(replace, s_unicode)
  return output

def clean_unicode_html(s_unicode) :
  clean_html = re.sub(u'&nbsp;', ' ', s_unicode)
  clean_html = re.sub(u'[\s]+', u' ', clean_html)

  pattern1 = re.compile(u'<script.+?</script>', re.I | re.M)
  clean_html = pattern1.sub(u'', clean_html)

  pattern2 = re.compile(u'<!\-\-.+?\-\->', re.M)
  clean_html = pattern2.sub(u'', clean_html)

  pattern3 = re.compile(u'<select.+?</select>', re.I | re.M)
  clean_html = pattern3.sub(u'', clean_html)

  pattern4 = re.compile(u'<style.+?</style>', re.I | re.M)
  clean_html = pattern4.sub(u'', clean_html)

  clean_html = re.sub(u'(?:&gt;|&lt;)', u' ', clean_html)

  pattern5 = re.compile(u'[\s]*</*[^>]+/*>[\s]*', re.I | re.M)
  clean_html = pattern5.sub(u' # ', clean_html)

  pattern6 = re.compile(u'\s[#\s]+', re.I | re.M)
  clean_html = pattern6.sub(u' # ', clean_html)
  
  return clean_html

def decode_html_entities(s_unicode) :
  #see :: def replace_num_entities()
  html = re.sub(u'&#([0-9]+);', replace_num_entities, s_unicode)
  pattern = re.compile(u'&([a-z]+);', re.I)
  #see :: def replace_alpha_entities()
  html = pattern.sub(replace_alpha_entities, html)
  return html

def replace_num_entities(matchobj_unicode) :
  if int(matchobj_unicode.group(1)) in range(65535):
    return unichr(int(matchobj_unicode.group(1)))
  else:
    return u'&#%s;'%(matchobj_unicode.group(1))

def replace_alpha_entities(matchobj_unicode) :
  k = matchobj_unicode.group(1)
  if not htmlentitydefs.entitydefs.has_key(k) :
    if k.isupper() :
      k = string.lower(matchobj_unicode.group(1))
      if not htmlentitydefs.entitydefs.has_key(cle) :
        return ''
    else :
      return ''
  if len(htmlentitydefs.entitydefs[k]) == 1 :
    car = htmlentitydefs.entitydefs[k]
    return unicode(car, 'iso-8859-1') #  car est codé en 'iso-8859-1' --> entitydefs[name] = chr(codepoint) dans htmlentitydefs
  else :
    str_code = htmlentitydefs.entitydefs[k].strip(u'&#;')
    return unichr(int(str_code))

