#!/usr/local/bin/pythonw
#-*- coding: utf-8 -*-

import sys
import os

import tp_1_2 as tp1
import tool_ltal as tl


def init_file(html_file):
    html_unicode=tp1.prepare_file(html_file)
    list_words=tp1.get_list_words(html_unicode)
    dict_effectif=tp1.list_words2dict_effectif(list_words)
    list_zipf=tp1.dict_effectif2distrib_zipf(dict_effectif)

    return (list_words,dict_effectif,list_zipf)


def clean_dic(dict_effect):
    list_exclude=['#','%','!','?',';',':','@','&','-','_','"','\'','(',')','*']
    for key in dict_effect:
        try:
            if isinstance(int(key),int):
                dict_effect=tl.supp_key_dic(dict_effect,key)
        except ValueError: #Si ce n'est pas un nombre
            for x in list(key):
                if x in list_exclude:
                    dict_effect=tl.supp_key_dic(dict_effect,key)
    return dict_effect

def listdic2dic(list_dic):
    dict_effect={}
    for dic in list_dic:
        for key in dic:
            if key in dict_effect:
                dict_effect[key]+=dic[key]
            else:
                dict_effect[key]=dic[key]

    return dict_effect
    
def write_ressource(name_file,dict_effect):
    s=''
    for key in dict_effect:
        s+=str(key.encode('utf-8'))+':'+str(dict_effect[key])+'\n'

    tl.write_file(name_file,s)


def file2dic(name_file):
    langue=name_file[-6:-4]
    dic={}
    with open(name_file,'r') as f:
        for line in f:
            pos=line.find(':')
            key,value=line[:pos],line[pos+1:-1]        
            dic[key]=int(value)

        return (dic,langue)

def create_dic(list_elem,dic):
    for elem in list_elem:
        if elem in dic:
            dic[elem]+=1
        else:
            dic[elem]=1
    return dic

def compare_dic(dic1,dic2):
    """
    Compare deux dico composés de mots (keys) et effectifs (values)
    score représente le nombres de mots identiques aux 2 dico
    """
    score=0
    for key in dic1:
        if key.encode('utf-8') in dic2.keys():
            score+=1
    return score

def ngramme(s,n):
    list_ngramme=[]
    pos=n
    if len(s) <=n:
        return s
    else:
        m=len(s)-n
        i=0
        while i<=m:
            list_ngramme+=[s[i:pos]]
            pos+=1
            i+=1
    return list_ngramme


def print_dic(dic,ordre=False):
    print "\n"
    for key in sorted(dic,reverse=ordre):
        print key,"-->",dic[key]
    print "\n"

