#!/usr/local/bin/pythonw
#-*- coding: utf-8 -*-

import sys
import os
import zlib

import tool_ltal as tl
import tp_1_2 as tp1
import tp3

def mat(taille):
    m=[[0]]
    m[0]*=taille
    m*=taille
    return m

def moyenne(l):
    res=0
    for val in l:
        res+=val
    return res/float(len(l))

def m_tuple(liste):
    l=[]
    for elem in liste:
        if isinstance(elem[0],int) or isinstance(elem[0],float):
            l.append(elem[0])
        else:
            l.append(elem[1])
    return l


def moy(liste):
    try:
        m=moyenne(m_tuple(liste))
        nouvelle_l1=[]
        nouvelle_l2=[]
        
        for elem in liste:
            if isinstance(elem[0],int) or isinstance(elem[0],float):
                nouvelle_l1.append(elem[1])
                val=elem[0]-m
            else:
                nouvelle_l1.append(elem[0])
                val=elem[1]-m
            if val < 0:
                val=-val
            
            nouvelle_l2.append(val)
            l=zip(nouvelle_l2,nouvelle_l1)
        
        return liste[l.index(min(l))]
    
    except:
        l=[]
        m=moyenne(liste)
        
        for elem in liste:
            val=elem-m
            
            if val < 0:
                val=-val
            
            l.append(val)
        return liste[l.index(min(l))]


def distance_doc(d1,d2):
    
    indata1 = open(d1, "rb").read()
    outdata1 = zlib.compress(indata1, zlib.Z_BEST_COMPRESSION)

    indata2 = open(d2, "rb").read()
    outdata2 = zlib.compress(indata2, zlib.Z_BEST_COMPRESSION)

    c1=len(outdata1)
    c2=len(outdata2)

    outdata3=zlib.compress(indata1+indata2, zlib.Z_BEST_COMPRESSION)
    c3=len(outdata3)

    return 1-(c1+c2-c3)/(float(max(c1,c2)))


def distance_group(g1,g2,mode):
    dic={}
    cle=0
    for d1 in g1:
        for d2 in g2:
            if d1!= d2 and (d2,d1) not in dic.keys():
                dic[distance_doc(d1,d2)]=(d1,d2)
                
                cle=mode(dic.keys())

    return cle

def fusion(g1,g2,list_doc):
    try:
        list_doc.remove(g1)
        list_doc.remove(g2)
    except ValueError:
        print "Erreur de suppression"
        return None
    list_doc+=[g1+g2]

def distance_itere1(list_doc,stack,mode,i=0):
    cle=[]
    val=[]
    for groupe in list_doc:
        for other_g in list_doc:
            if [other_g,groupe] not in val and groupe!=other_g:
                cle+=[distance_group(groupe,other_g,mode)]
                val.append([groupe,other_g])
            

    res=mode(zip(cle,val))
    stack.append(res)
    
    fusion(stack[i][1][0],stack[i][1][1],list_doc)


def creer_data(list_doc,stack,mode):
    i=0
    while len(list_doc)!=1:
        distance_itere1(list_doc,stack,mode,i)
        print '\nliste de docs      =>',list_doc
        print 'stack               =>',stack
        print 'nombre d\'iteration  =>',i+1
        i+=1
        print '\n-------------------------------------------------------\n'

def cree_matrice(list_doc,mode):
    l=[]
    for d in list_doc:
        l+=d
    m=[]
    for i in range(len(l)):
        res=[]
        for j in range(len(l)):
            res+=[distance_doc(l[i],l[j])]
        m+=[res]
    return m

def moyenne_m(matrice):
    res=0
    somme=0
    for ligne in matrice:
        somme+=sum(ligne)
        
    res=float(somme)/(len(matrice)**2)
    return res

def sciCate_m(matrice,moy):
    res=[[],[]]
    for ligne in matrice:
        for val in ligne:
            if val < moy:
                res[0]+=[val]
            else:
                res[1]+=[val]
                
    res[0]=list(set(res[0]))
    res[1]=list(set(res[1]))

    return res

def sep(l,val):
    res=[[],[]]
    for x in l:
        if x < val:
            res[0]+=[x]
        else:
            res[1]+=[x]

    return res

def applatir(l):
    try:
        iter(l)
    except TypeError:
        yield l
    else:
        for elem in l:
            for subelem in applatir(elem):
               yield subelem


def moy_begin(matrice,nb_classe):
    if nb_classe<1:
        return "Error"
    if nb_classe==1:
        r=list(applatir(matrice))
        s=sep(r,sum(r)/float(len(r)))
        return s

def moy_emboite(mat,nb_classe):
    mat=moy_begin(mat,1)

    if nb_classe==1:
        return mat

    for n in range(nb_classe-1):
        res=[]
        for i in range(len(mat)):
            s=sep(mat[i],sum(mat[i])/float(len(mat[i])))
            res+=s
        mat=res
    return res



def trouve(mat,val):
    for i in range(len(mat)):
        if val in mat[i]:
            return i
    return None


def print_legende_haut(list_docs):
    tab='''
    '''
    tab+='''
        <td style="background-color:rgb(255,255,255);">'''+'          '+'''</td>
        '''
    for elem in list_docs:
        tab+='''
        <td style="background-color:rgb(255,255,255);">'''+str(elem)+'''</td>
        '''

    return tab
    
    

def print_ligne(list_docs,ligne,j,mat_moyenne):
    tranche=140.0/len(mat_moyenne)
    tab='''
    <tr>
    '''
    
    tab+='''
        <td style="background-color:rgb(255,255,255);">'''+str(list_docs[j])+'''</td>
        '''
    i=0
    for elem in ligne:
        nom=''
        val=0
        index=trouve(mat_moyenne,elem)

        if index==None:
            return "Error"
        else:
            val=index*tranche
            nom=str(elem)

        i+=1

        val=str(val)
        tab+='''
        <td style="background-color:hsl('''+val+''', 100%, 50%);">'''+nom+'''</td>
        '''

    tab+='''
    </tr>
    '''

    return tab


def print_tab(html_file,list_docs,matrice,mat_moyenne):
    header=tp1.get_header_html()
    footer=tp1.get_footer_html()
    
    tab='''
    <table>
    '''
    tab+=print_legende_haut(list_docs)

    for i in range(len(matrice)):
        tab+=print_ligne(list_docs,matrice[i],i,mat_moyenne)

    tab+='''
    </table>
    '''
    
    tl.write_file(str(html_file),str(header+tab+footer))

def append_name(list_file,path):
    res=[]
    for f in list_file:
        res+=[str(path)+'\\'+f]
    return res


def create_list_corpus(path_corpus):
    path=os.getcwd()
    path_corpus=os.getcwd()+str(path_corpus)
    os.chdir(path_corpus)
    list_dir=[]
    for rep in os.listdir(os.getcwd()):
        os.chdir(os.getcwd()+'\\'+str(rep))
        list_dir+=[append_name(os.listdir(os.getcwd()),os.getcwd())]
        os.chdir(path_corpus)

    os.chdir(path)

    return list_dir


########################### Main #####################################


if __name__=='__main__' :
    path_corpus = sys.argv[1]
    
    distance = sys.argv[2]
    nb_classe = sys.argv[3]
    path_corpus='/'+ path_corpus
    os.chdir(os.getcwd()+str(path_corpus))
    
    list_doc1=os.listdir(os.getcwd())
    
    list_doc2=[[x] for x in list_doc1]
    
    stack=[]
    if distance=='max':
        distance=max
    if distance=='min':
        distance=min
    if distance=='moy':
        distance=moy
    
    creer_data(list_doc2,stack,distance)
    
    l1=cree_matrice(list_doc2,distance)
    
    mat_moyenne=moy_emboite(l1,int(nb_classe))
    
    print_tab("color.html",list_doc1,l1,mat_moyenne)
    
