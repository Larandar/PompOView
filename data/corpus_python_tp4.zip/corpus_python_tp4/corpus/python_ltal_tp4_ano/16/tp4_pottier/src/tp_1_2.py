#!/usr/local/bin/pythonw
# -*- coding: utf-8 -*-

import re
import os
import sys

import tool_ltal as tl

def get_header_html(css_path='') :
  s = '''
  <html>
    <head>
      <meta http-equiv="Content-Type"
            content="text/html; charset=utf-8">
      '''
  if css_path!='' and isinstance(css_path,str):
    tl.write_file(css_path,"/*CSS File*/\n\n")
    s+='''
    <link rel="stylesheet" media="screen" type="text/css"
    title="CSS" href="'''+css_path+'''" />
    '''
  s+='''
      <title>Titre</title>
    </head>
    <body>
  '''
  return s

def get_footer_html() :
  s = '''
    </body>
  </html>
  '''
  return s

def prepare_file(path_file):
  src_html = tl.read_file(path_file)
  encoding_detected = tl.source2encoding(src_html)
  src_html_unicode = unicode(src_html,encoding_detected)
  src_html_unicode = tl.clean_unicode_html(src_html_unicode)
  src_html_unicode = tl.decode_html_entities(src_html_unicode)
  return src_html_unicode

def extract_title(html_unicode):
  pattcomp = re.compile(u'<title>(.+)<\/title>', re.I)
  trouv_titre = re.search(pattcomp, html_unicode)
  #trouv_titre = pattcomp.match(html_unicode)
  if trouv_titre:
    return trouv_titre.group(1)
  return ''

def get_list_words(html_unicode):
  pattern_word = u'[^\s\'".?;,:!\(\)\[\]\|]+'
  pattern_word_compiled = re.compile(pattern_word)
  list_words = pattern_word_compiled.findall(html_unicode)
  return list_words

def get_list_char(html_unicode):
  pattern_char = u'[^\s\'".?;,:!\(\)\[\]\|]{1,1}'
  pattern_char_compiled = re.compile(pattern_char)
  list_chars = pattern_char_compiled.findall(html_unicode)
  return list_chars

def list_words2dict_effectif(list_words_unicode):
  dict_effectif = {}
  for graphie in list_words_unicode :
    tl.dict_count(dict_effectif, graphie)
  return dict_effectif

def list_chars2dict_effectif(list_chars_unicode):
  return list_words2dict_effectif(list_chars_unicode)


def dict_effectif2distrib_zipf(dict_effectif):
  l = []
  for graphie,effectif in dict_effectif.iteritems():
    l.append(effectif)
  l = sorted(l, reverse=True)
  return l

def main(path_file):
  src_html_brut = unicode(tl.read_file(path_file),'utf-8')
  src_html_unicode = prepare_file(path_file)
  title_detected = extract_title(src_html_brut)
  if title_detected != '' :
    str_t = '<p>%s</p>'%(title_detected)
  else :
    str_t = '<p>nop</p>'

  l = get_list_words(src_html_unicode)
  d = list_words2dict_effectif(l)
  z = dict_effectif2distrib_zipf(d)

  it = d.items()
  def cmpval(x,y) :
    return y[1] - x[1]
  it.sort(cmpval)

  str_z = tl.ltuple2ul(it)

  str_h = get_header_html()
  str_f = get_footer_html()

  output_zipf = '%s %s %s %s'%(str_h, str_t, str_z, str_f)

  s_color = 'chaîne de carac'
  s_color = unicode(s_color,'utf-8')
  src_html_unicode = unicode(tl.read_file(path_file),'utf-8')
  output_color = tl.color_string(src_html_unicode, s_color,'#AA2222')

  return output_zipf,output_color

if __name__=='__main__' :
  path_file = sys.argv[1]
  outputzipf, outputcolor = main(path_file)

  outputzipf_utf8 = outputzipf.encode('utf-8')
  tl.write_file('out_zipf.html',outputzipf_utf8)

  outputcolor_utf8 = outputcolor.encode('utf-8')
  tl.write_file('color.html',outputcolor_utf8)


