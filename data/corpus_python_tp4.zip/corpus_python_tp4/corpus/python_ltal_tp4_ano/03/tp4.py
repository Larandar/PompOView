﻿#!/usr/local/bin/pythonw
# -*- coding: utf-8 -*-

import zlib, glob, sys, re

def prepare_file(path_file) :
  src_html = read_file(path_file)
  #encoding_detected = source2encoding(src_html)
  src_html_unicode = unicode(src_html,"utf-8")
  src_html_unicode = clean_unicode_html(src_html_unicode)
  src_html_unicode = decode_html_entities(src_html_unicode)
  return src_html_unicode

def get_list_words(html_unicode) :
  pattern_word = u'[^\s\'".?;,:!\(\)\[\]\|]+'
  pattern_word_compiled = re.compile(pattern_word)
  list_words = pattern_word_compiled.findall(html_unicode)
  return list_words

def list_words2dict_effectif(list_words_unicode) :
  dict_effectif = {}
  for graphie in list_words_unicode :
    dict_count(dict_effectif, graphie)
  return dict_effectif

def dict_count(d, k) :
  if(d.has_key(k)) :
    d[k] += 1
  else :
    d[k] = 1

def read_file(path_file) :
  f = open(path_file, 'r')
  s = f.read()
  f.close()
  return s

def write_file(path_file, s) :
  f = open(path_file, 'w')
  f.write(s)
  f.close()

def clean_unicode_html(s_unicode) :
  clean_html = re.sub(u'&nbsp;', ' ', s_unicode)
  clean_html = re.sub(u'[\s]+', u' ', clean_html)

  pattern1 = re.compile(u'<script.+?</script>', re.I | re.M)
  clean_html = pattern1.sub(u'', clean_html)

  pattern2 = re.compile(u'<!\-\-.+?\-\->', re.M)
  clean_html = pattern2.sub(u'', clean_html)

  pattern3 = re.compile(u'<select.+?</select>', re.I | re.M)
  clean_html = pattern3.sub(u'', clean_html)

  pattern4 = re.compile(u'<style.+?</style>', re.I | re.M)
  clean_html = pattern4.sub(u'', clean_html)

  clean_html = re.sub(u'(?:&gt;|&lt;)', u' ', clean_html)

  pattern5 = re.compile(u'[\s]*</*[^>]+/*>[\s]*', re.I | re.M)
  clean_html = pattern5.sub(u' # ', clean_html)

  pattern6 = re.compile(u'\s[#\s]+', re.I | re.M)
  clean_html = pattern6.sub(u' # ', clean_html)

  pattern7 = re.compile(u'<[^]+>', re.I | re.M)
  clean_html = pattern7.sub(u' ', clean_html)
  
  return clean_html

def distance_info(text1, text2):
	t12 = text1 + text2
	c_t1  = float(len(zlib.compress(text1, zlib.Z_BEST_COMPRESSION)))
	c_t2  = float(len(zlib.compress(text2, zlib.Z_BEST_COMPRESSION)))
	c_t12 = float(len(zlib.compress(t12, zlib.Z_BEST_COMPRESSION)))

	distance =  1 - ((c_t1 + c_t2) - c_t12) / max(c_t1,c_t2)
	return distance

def generer_matrice(l, d):
	#l = glob.glob(chemin/*)
	m = {}
	for i, f1 in enumerate(l):
		t1 = read_file(f1)
		for j, f2 in enumerate(l):
			if i < j:
				continue
			if i == j:
				m[(i,j)] = m[(j,i)] = d(t1,t2)
				
	

#0 : tp4.py
#1 : path corpus a analyser
#2 : distance
#3 : nombre de classe

if __name__=='__main__' :
  file_list = []
  if len(sys.argv) == 4:
		dossier = sys.argv[1]
		for file in glob.glob(dossier+'\\*'):
			file_list.append(file)
			
  fichiers_traites = []

  for i in file_list:
	content = unicode(read_file(i))
	clean_unicode_html(content)
	fichiers_traites.append(content)
	
	generer_matrice(fichiers_traites, distance_info)
	