﻿#!/usr/local/bin/pythonw
# -*- codage : utf-8 -*-
# -*- auteur : BRUYERE Julien -*-
# -*- date : 17 Novembre 2011 -*-
# -*- role : forme des groupes de documents -*-


############################################################
##                                                        ##
##               Importations librairies                  ##
##                                                        ##
############################################################

import re, os, sys, glob

import htmlentitydefs
import zlib


############################################################
##                                                        ##
##                      Fonctions                         ##
##                                                        ##
############################################################

# Lit un fichier
def read_file(path_file) :
  f = open(path_file, 'r')
  s = f.read()
  f.close()
  return s

# Ecrit un fichier
def write_file(path_file, s) :
  f = open(path_file, 'w')
  f.write(s)
  f.close()


# Nettoie le code HTML
def clean_unicode_html(s_unicode) :
  clean_html = re.sub(u'&nbsp;', ' ', s_unicode)
  clean_html = re.sub(u'[\s]+', u' ', clean_html)

  pattern1 = re.compile(u'<script.+?</script>', re.I | re.M)
  clean_html = pattern1.sub(u'', clean_html)

  pattern2 = re.compile(u'<!\-\-.+?\-\->', re.M)
  clean_html = pattern2.sub(u'', clean_html)

  pattern3 = re.compile(u'<select.+?</select>', re.I | re.M)
  clean_html = pattern3.sub(u'', clean_html)

  pattern4 = re.compile(u'<style.+?</style>', re.I | re.M)
  clean_html = pattern4.sub(u'', clean_html)

  clean_html = re.sub(u'(?:&gt;|&lt;)', u' ', clean_html)

  pattern5 = re.compile(u'[\s]*</*[^>]+/*>[\s]*', re.I | re.M)
  clean_html = pattern5.sub(u' ', clean_html)

  pattern6 = re.compile(u'\s[#\s]+', re.I | re.M)
  clean_html = pattern6.sub(u' ', clean_html)

  pattern7 = re.compile(u'<[^>]+>+', re.I | re.M)
  clean_html = pattern7.sub(u'', clean_html)
  
  return clean_html


def replace_num_entities(matchobj_unicode) :
  if int(matchobj_unicode.group(1)) in range(65535):
    return unichr(int(matchobj_unicode.group(1)))
  else:
    return u'&#%s;'%(matchobj_unicode.group(1))


def replace_alpha_entities(matchobj_unicode) :
  k = matchobj_unicode.group(1)
  if not htmlentitydefs.entitydefs.has_key(k) :
    if k.isupper() :
      k = string.lower(matchobj_unicode.group(1))
      if not htmlentitydefs.entitydefs.has_key(cle) :
        return ''
    else :
      return ''
  if len(htmlentitydefs.entitydefs[k]) == 1 :
    car = htmlentitydefs.entitydefs[k]
    return unicode(car, 'iso-8859-1') 
  else :
    str_code = htmlentitydefs.entitydefs[k].strip(u'&#;')
    return unichr(int(str_code))


def decode_html_entities(s_unicode) :
  #see :: def replace_num_entities()
  html = re.sub(u'&#([0-9]+);', replace_num_entities, s_unicode)
  pattern = re.compile(u'&([a-z]+);', re.I)
  #see :: def replace_alpha_entities()
  html = pattern.sub(replace_alpha_entities, html)
  return html




# Fournit un haut de page de site Web
def get_header_html() :
  s = '''
  <html>
    <head>
      <meta http-equiv="Content-Type"
            content="text/html; charset=utf-8">
      <title>Matrice</title>
    </head>
    <body>

    <h1><u>Tableau de similarit&eacute</u></h1>
  '''
  return s


# Fournit un pied de page de site Web
def get_footer_html() :
  s = '''
    </body>
  </html>
  '''
  return s


# Créé une liste de liste par moyenne
def moyenne_emboiter(liste, nb_decoupage):
    lg = []
    ld = []

    moy = sum(liste)/len(liste)

    for e in liste:
        if e <= moy:        # moyenne situer a gauche si moyenne = valeur
            lg.append(e)
        else:
            ld.append(e)
            
    if nb_decoupage!=1:
      lg = moyenne_emboiter(lg, nb_decoupage-1)
      ld = moyenne_emboiter(ld, nb_decoupage-1)

    return [lg, ld]
  

# Aplanit la liste de listes (le resultat est gbl_liste)
gbl_liste=[]

def aplanit(liste, nb_decoupage):
  
  if nb_decoupage != 1:
    aplanit(liste[0], nb_decoupage-1)
    aplanit(liste[1], nb_decoupage-1)
  else:
    gbl_liste.append(liste[0])
    gbl_liste.append(liste[1])


# Créé une echelle adaptée au decoupage
def get_color_scale(nb_decoupage) :
  dico={}

  intervalle_couleur = 120/(pow(2,nb_decoupage)-1) # 2^n listes (-1 pour avoir les intervalles)

  for i in range(pow(2,nb_decoupage)):
    for val in gbl_liste[i]:
      dico[val]=i*intervalle_couleur
    
  return dico

# Créé le fichier HTML contenant la matrice
def afficher_matrice(liste_doc, matrice, nb_decoupage):
  
  h = get_header_html()
  f = get_footer_html()

  liste_valeur = moyenne_emboiter(sorted(matrice.values()), nb_decoupage)

  aplanit(liste_valeur, nb_decoupage) # Le resultat est gbl_liste (utilisé dans get_color_scale)
  
  color_dict = get_color_scale(nb_decoupage)

  z = '''
    <table style="collapse:collapse;" cellspacing="0">
      <tr>
        '''

  for i in range(len(liste_doc)):  
    for j in range(len(liste_doc)):
      if i==j:
        z+='''
        <td style="font-size:11px;padding:2px;background-color:hsl(0, 100%, 50%);">
        0.00
        </td>
          '''
      else:
        valeur = str(matrice[(i,j)])
        
        z+='''
        <td style="font-size:11px;padding:2px;background-color:hsl('''+str(color_dict[matrice[(i,j)]])+''', 100%, 50%);">
        '''+valeur[:4]+'''
        </td>
          '''
        
    z+='''
        <td style="font-size:11px;">%s</td>
      </tr>
        '''%(liste_doc[i])

  z+='''<tr>

    '''


  for i in range(len(liste_doc)):
    z+='<td valign="top" style="font-size:11px;">'
    
    for j in range(len(liste_doc[i])):
      z+='%s<br/>'%(liste_doc[i][j:j+1])
      
    z+='''</td>
      '''

  

  z+='''
      </tr>
    </table>
  '''

  outputzipf = '%s %s %s'%(h, z, f)
  outputzipf_utf8 = outputzipf.encode('utf-8')
  write_file("Sortie/matrice.html" ,outputzipf_utf8)




# Prépare le fichier à l'exploitation
def prepare_file(path_file, html_naturel) :
  src_html = read_file(path_file)

  if html_naturel == 1:
    src_html_unicode = unicode(src_html,'utf-8')
    src_html_unicode = clean_unicode_html(src_html_unicode)
    src_html_unicode = decode_html_entities(src_html_unicode)

  return src_html # normalement src_html_unicode, mais ne marche pas

    
# Distance informationnelle
def distance_info(text1, text2):
    text12 = text1 + text2
    taille_comp_t1  = float(len(zlib.compress(text1, zlib.Z_BEST_COMPRESSION)))
    taille_comp_t2  = float(len(zlib.compress(text2, zlib.Z_BEST_COMPRESSION)))
    taille_comp_t12 = float(len(zlib.compress(text12, zlib.Z_BEST_COMPRESSION)))

    distance =  1 - ((taille_comp_t1 + taille_comp_t2) - taille_comp_t12) / max(taille_comp_t1,taille_comp_t2)
    return distance

# Créé une matrice de distance des textes entre eux
def generer_matrice(liste_doc, fct, html_naturel):
    m={}

    for i, f1 in enumerate(liste_doc):
        t1 = prepare_file(f1, html_naturel)
        
        for j, f2 in enumerate(liste_doc):
            t2 = prepare_file(f2, html_naturel)

            if i<=j:
                continue
            m[(i,j)]=fct(t1,t2)
            m[(j,i)]=m[(i,j)]

    return m






# Non utilisé
def distance_groupe(g1,g2, m, typ):
    l=[]
    for i in g1:
        for j in g2:
            l.append(m[(i,j)])

    return typ(l) # min, max ou avg  (math.avg)

  


############################################################
##                                                        ##
##                         Main                           ##
##                                                        ##
############################################################



if __name__=='__main__' :

  corpus_a_analyser = sys.argv[1]
  html_naturel = int(sys.argv[2])
  distance = sys.argv[3]
  nb_decoupage = int(sys.argv[4])

  # Cherche la liste des documents du dossier 
  liste_doc = glob.glob("%s/*"%(corpus_a_analyser))

  # Genere une matrice
  matrice = generer_matrice(liste_doc, distance_info, html_naturel)

  # Produit le document HTML
  afficher_matrice(liste_doc, matrice, nb_decoupage)



    



  
