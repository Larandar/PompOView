# -*- coding: utf-8 -*-

import re
import os
import sys
import zlib
import glob

def read_file(path_file) :
  f = open(path_file, 'r')
  s = f.read()
  f.close()
  return s

def clean_unicode_html(s_unicode) :
  clean_html = re.sub(u'&nbsp;', ' ', s_unicode)
  clean_html = re.sub(u'[\s]+', u' ', clean_html)

  pattern1 = re.compile(u'<script.+?</script>', re.I | re.M)
  clean_html = pattern1.sub(u'', clean_html)

  pattern2 = re.compile(u'<!\-\-.+?\-\->', re.M)
  clean_html = pattern2.sub(u'', clean_html)

  pattern3 = re.compile(u'<select.+?</select>', re.I | re.M)
  clean_html = pattern3.sub(u'', clean_html)

  pattern4 = re.compile(u'<style.+?</style>', re.I | re.M)
  clean_html = pattern4.sub(u'', clean_html)

  clean_html = re.sub(u'(?:&gt;|&lt;)', u' ', clean_html)

  pattern5 = re.compile(u'[\s]*</*[^>]+/*>[\s]*', re.I | re.M)
  clean_html = pattern5.sub(u' # ', clean_html)

  pattern6 = re.compile(u'\s[#\s]+', re.I | re.M)
  clean_html = pattern6.sub(u' # ', clean_html)
  
  return clean_html

def decode_html_entities(s_unicode) :
  #see :: def replace_num_entities()
  html = re.sub(u'&#([0-9]+);', replace_num_entities, s_unicode)
  pattern = re.compile(u'&([a-z]+);', re.I)
  #see :: def replace_alpha_entities()
  html = pattern.sub(replace_alpha_entities, html)
  return html
def replace_num_entities(matchobj_unicode) :
  if int(matchobj_unicode.group(1)) in range(65535):
    return unichr(int(matchobj_unicode.group(1)))
  else:
    return u'&#%s;'%(matchobj_unicode.group(1))

def replace_alpha_entities(matchobj_unicode) :
  k = matchobj_unicode.group(1)
  if not htmlentitydefs.entitydefs.has_key(k) :
    if k.isupper() :
      k = string.lower(matchobj_unicode.group(1))
      if not htmlentitydefs.entitydefs.has_key(cle) :
        return ''
    else :
      return ''
  if len(htmlentitydefs.entitydefs[k]) == 1 :
    car = htmlentitydefs.entitydefs[k]
    return unicode(car, 'iso-8859-1') #  car est codé en 'iso-8859-1' --> entitydefs[name] = chr(codepoint) dans htmlentitydefs
  else :
    str_code = htmlentitydefs.entitydefs[k].strip(u'&#;')
    return unichr(int(str_code))

def prepare(file):
	src_html = read_file(file)# lecture fichier
	src_html_unicode = unicode(src_html,"UTF-8")# transformation vers unicode
	src_html_unicode = clean_unicode_html(src_html_unicode)# enleve ou remplace les balises HTML par le caractere '#'
	src_html_unicode = decode_html_entities(src_html_unicode)

def distance_info(text1, text2):
    t12 = text1 + text2
    c_t1  = float(len(zlib.compress(text1, zlib.Z_BEST_COMPRESSION)))
    c_t2  = float(len(zlib.compress(text2, zlib.Z_BEST_COMPRESSION)))
    c_t12 = float(len(zlib.compress(t12, zlib.Z_BEST_COMPRESSION)))

    distance =  1 - ((c_t1 + c_t2) - c_t12) / max(c_t1,c_t2) 
    return distance

def moyenne_emboiter(liste,nb_it):
	m={}
	l = glob.glob("%s*"%(liste))
	for i,f1 in enumerate(l):
	    t1 = f1
            #t1 = prepare(f1)
	    for j,f2 in enumerate(l):
	       t2 = f2
               #t2 = prepare(f2)
	       if i < j:
	           continue
               m[(i,j)] = m[(j,i)] = distance_info(t1,t2)
	return m

if __name__=='__main__' :
	#text1 = sys.argv[1]
	#text2 = sys.argv[2]
	#dist = distance_info(text1,text2)
	#print dist
	
	liste = sys.argv[1]
	res = moyenne_emboiter(liste,3)
	print res

	

	

			
		
	


