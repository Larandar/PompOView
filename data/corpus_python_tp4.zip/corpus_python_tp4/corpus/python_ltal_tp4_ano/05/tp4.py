# -*- coding: utf-8 -*-
import time
import operator
import os
import sys
import zlib

import html
import output
	
def processText(text1, text2):
	text1 = text1.encode("utf-8")
	text2 = text2.encode("utf-8")
	t12 = text1 + text2
	
	# c_t1  = float(len(zlib.compress(text1, zlib.Z_BEST_SPEED)))
	# c_t2  = float(len(zlib.compress(text2, zlib.Z_BEST_SPEED)))
	# c_t12 = float(len(zlib.compress(t12, zlib.Z_BEST_SPEED)))
	
	c_t1  = float(len(zlib.compress(text1, zlib.Z_BEST_COMPRESSION)))
	c_t2  = float(len(zlib.compress(text2, zlib.Z_BEST_COMPRESSION)))
	c_t12 = float(len(zlib.compress(t12, zlib.Z_BEST_COMPRESSION)))	
	
	distance =  1 - ((c_t1 + c_t2) - c_t12) / max(c_t1,c_t2)
	return distance
	
def generer_matrice(l, func,folder):
	m = {}
	for i, f1 in enumerate(l):
		t1 = html.read_clean(folder+f1)
		
		for j, f2 in enumerate(l):
			if i < j:
				continue
				
			t2 = html.read_clean(folder+f2)
			
			if i == j:
				m[ (i, i) ] = 0
				
			else:
				d = func(t1, t2)
				m[ (i, j) ] = m[ (j, i) ] = d
	
	return m
	
def mat2list(mat,taille):
	l = []
	for i in xrange(taille):
		for j in xrange(i+1,taille):
			l.append([mat[i,j],(i,j)])
			
	return l
	
def sum_list(liste):
	x = 0
	for i in liste:
		x += i[0]
		
	return x
				
def moyenne_emboitee(liste,nb_it,val=0,res=[]):
	if res == []:
		for i in xrange(2**nb_it):
			res.append(())
			
		res[0] = liste
		
	if liste!=[] and nb_it!=0:
		if len(liste)>1:
			liste_gauche, liste_droite = [], []
			moyenne = sum_list(liste)/float(len(liste))
			for i in liste:
				if i[0]<moyenne:
					liste_gauche.append(i)
					
				else:
					liste_droite.append(i)
					
			res[val] = [x[1] for x in liste_gauche]
			res[val+2**(nb_it-1)] = [x[1] for x in liste_droite]
			moyenne_emboitee(liste_gauche,nb_it-1,val,res) , moyenne_emboitee(liste_droite,nb_it-1,val+2**(nb_it-1),res)
			
	return res
	
def select_min(mat):
	l = []
	q = []
	for x in mat:
		if x[0] != x[1] and not (x[1], x[0]) in l:
			l.append(x)
			q.append(mat[x])
	
	return l[q.index(min(q))]
	
def dendrogramme(mat, function):
	ordre = {0:-1}
	i = 0
	while len(mat) > 1:
		key1, key2 = select_min(mat)
		ordre[(key1,key2)] = i
		i += 1
		ordre[i] = -1
		temp = {}
		for keys in mat:
			if keys!=(key1,key2) and keys!=(key2,key1) and keys[0] != keys[1]:
				if key1==keys[0] and key2!=keys[1]:
					temp[(key1, key2),keys[1]] = function(mat[key1, keys[1]], mat[key2, keys[1]])
					temp[keys[1], (key1, key2)] = function(mat[key1, keys[1]], mat[key2, keys[1]])
				elif key1==keys[1] and key2!=keys[0]:
					temp[(key1, key2),keys[0]] = function(mat[key1, keys[0]], mat[key2, keys[0]])
					temp[keys[0], (key1, key2)] = function(mat[key1, keys[0]], mat[key2, keys[0]])
				elif key2==keys[0] and key1!=keys[1]:
					temp[(key1, key2),keys[1]] = function(mat[key1, keys[1]], mat[key2, keys[1]])
					temp[keys[1], (key1, key2)] = function(mat[key1, keys[1]], mat[key2, keys[1]])
				elif key2==keys[1] and key1!=keys[0]:
					temp[(key1, key2),keys[0]] = function(mat[key1, keys[0]], mat[key2, keys[0]])
					temp[keys[0], (key1, key2)] = function(mat[key1, keys[0]], mat[key2, keys[0]])
				else:
					temp[keys] = mat[keys]
					
		mat = temp
		
	return (key1, key2), ordre
	
def appalatit_dendrogramme(dend, ordre):
	if type(dend) != type(()): # si dend est une feuille (donc pas un tuple)
		return str(dend) + ' '
		
	elem1, elem2 = dend
	
	if ordre[elem1] >= ordre[elem2]:
		return appalatit_dendrogramme(elem1, ordre) + appalatit_dendrogramme(elem2, ordre)
	else:
		return appalatit_dendrogramme(elem2, ordre) + appalatit_dendrogramme(elem1, ordre)
	
def moy(i, j):
	return (i+j)/2.
	
if __name__ == '__main__':
	
	folder, meth_name, nb_it = sys.argv[1], sys.argv[2], int(sys.argv[3])
	meth = {"min": min, "max": max, "moy": moy}[meth_name]	
	folder_list = [x for x in os.listdir(folder) if os.path.isdir(folder+'/'+x)]
	
	for language in folder_list:
		t = time.time()
		
		current_folder = folder+'/'+language+'/'
		l = os.listdir(current_folder)
		
		mat = generer_matrice(l, processText,current_folder)
		me = moyenne_emboitee(mat2list(mat, len(l)),nb_it) 
			
		dendr, ordre = dendrogramme(mat, meth)
		dend = appalatit_dendrogramme(dendr[:], ordre).split()
		
		output.drawDendrogramme(dendr, ordre, dend, l, language, folder, meth_name)			
		output.output_mat(mat, l, me,dend,language,nb_it, folder, meth_name)
		
		print 'Folder %s done in %f s'%(language,time.time()-t)