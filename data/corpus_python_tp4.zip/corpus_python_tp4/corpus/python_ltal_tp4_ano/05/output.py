# -*- coding: utf-8 -*-

def find_color(liste, val):
	if liste:
		for x,i in enumerate(liste):
			if val in i:
				return x+1
	else:
		return None

def output_mat(matrice, l, me,dend,language,nb_it, dir, meth):
	h = """
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
	<head>
	<title>Résultat sur la langue %s avec la méthode %s</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	</head>
	<body>
	<p>Résultat sur la langue %s avec la méthode %s</p>
	<table border="0" cellspacing="0">
	<tr><td></td>
	"""%(language, meth, language, meth)
	for i, x in enumerate(dend):
		h += "<td>%s</td>"%(l[int(x)])
		
	h += "</tr>"
		
	p = "</table></body></html>"
	
	b = ""
	
	for i,x in enumerate(dend):
		val_x = int(x)
		b += "<tr><td>%s</td>"%(l[val_x])
		for j,y in enumerate(dend):
			val_y = int(y)
			if x!=y:
				coul = find_color(me,(val_x,val_y)) or find_color(me,(val_y,val_x))
				color = (120/(nb_it)**2)*(coul) #if coul!=len(l) else 120
				b += "<td style=\"background-color:hsl(%f, 100%%, 50%%);\">%f</td>"%(color,matrice[(val_x, val_y)])
				
			else:
				b += "<td style=\"background-color:hsl(0, 100%%, 50%%);\">%f</td>"%(matrice[(val_x, val_y)])
				
		b += "</tr>"
		
	with open("%s/sortie_%s_%s.html"%(dir, language, meth), 'w') as f:
		f.write(h + b + p)
		
def position(dend, key):
	if type(key) == type(1):
		return dend.index(str(key))
	else:
		key1, key2 = key
		return ( position(dend, key1) + position(dend, key2) ) / 2.
		
def drawDendrogramme(dendr, ordre, dend, l, lang, dir, meth):

	h = len(dend) - 1
	t = ""
	
	# tree_ord contient la liste des fusions par ordre chronologique
	tree_ord = [i[1] for i in sorted([(ordre[x], x) for x in ordre if ordre[x] >= 0])]
	deb_y = h*30 + 50
	
	le = len(l)
	for x in xrange(le):	
		t += '<text x="%d" y="%d" transform="rotate(45 %d,%d)">%s</text>'%(x*50 + 20, deb_y+10, x*50 + 20, deb_y+10, l[int(dend[x])])	
	
		t += '<line x1="0" y1="%d" x2="%d" y2="%d" style="stroke-dasharray: 9, 5; stroke: #E5E5FF; stroke-width: 1;" />'%(
				x*30+35, le*50+20, x*30+35)
		t += '<text x="%d" y="%d" style="fill: #5656A5;">%d</text>'%(le*50+25, x*30+40, x+1)
	
	for x in xrange(h):
		pos1 = position(dend, tree_ord[x][0]) * 50 + 25
		pos2 = position(dend, tree_ord[x][1]) * 50 + 25
		
		d1 = (deb_y - ordre[tree_ord[x][0]]*30 - 30)
		d2 = (deb_y - ordre[tree_ord[x][1]]*30 - 30)
		h = deb_y-x*30-30
		t += '<line x1="%d" y1="%d" x2="%d" y2="%d" style="stroke:#006600;" />'%(pos1, h, pos1, d1)
		t += '<line x1="%f" y1="%f" x2="%f" y2="%f" style="stroke:#006600;" />'%(pos2, h, pos2, d2)
		
		t += '<line x1="%d" y1="%d" x2="%d" y2="%d" style="stroke:#006600;" />'%(pos1, h, pos2, h)
	
	m = (pos1 + pos2)/2.
	t += '<line x1="%d" y1="%d" x2="%d" y2="%d" style="stroke:#006600;" />'%(m, h, m, h-30)
	
	s = """
<?xml-stylesheet type="text/css" href="svg-stylesheet.css" ?>
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
%s
</svg>
	"""%(t)
	
	with open("%s/dend_%s_%s.svg"%(dir, lang, meth), 'w') as f:
		f.write(s)		