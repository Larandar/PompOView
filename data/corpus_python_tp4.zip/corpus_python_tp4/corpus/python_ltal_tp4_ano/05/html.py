# -*- coding: utf-8 -*-
import htmlentitydefs
import re
import chardet

def decode_html_entities(s_unicode):
	#see :: def replace_num_entities()
	html = re.sub(u"&#([0-9]+);", replace_num_entities, s_unicode)
	pattern = re.compile(u"&([a-z]+);", re.I)
	#see :: def replace_alpha_entities()
	html = pattern.sub(replace_alpha_entities, html)
	return html

def replace_num_entities(matchobj_unicode):
	if 0 <= int(matchobj_unicode.group(1)) < 65535:
		return unichr(int(matchobj_unicode.group(1)))

	return u"&#%s;"%(matchobj_unicode.group(1))

def replace_alpha_entities(matchobj_unicode):
	k = matchobj_unicode.group(1)
	if not htmlentitydefs.entitydefs.has_key(k) :
		if k.isupper():
			k = string.lower(matchobj_unicode.group(1))
			if not htmlentitydefs.entitydefs.has_key(k):
				return u''
		else :
			return u''
	if len(htmlentitydefs.entitydefs[k]) == 1:
		return unicode(htmlentitydefs.entitydefs[k], "iso-8859-1")
	
	return unichr(int(htmlentitydefs.entitydefs[k].strip(u"&#;")))

def read_clean(path):
	"""Lit et retourne le contenu d'un fichier netoyé."""
	with open(path, 'r') as f:
		data = f.read()	
	extension = path.split('.')[-1]
	try:
		u_data = unicode(data, 'utf-8') #Encode le fichier utf-8 en unicode.
	except:
		try:
			u_data = unicode(data, chardet.detect(data)["encoding"])
		except:
			print "Impossible de détecter l'encoding du fichier %s"%(path)
			return ""
		
	if extension=='xml':
		u_data = re.sub("</?.+?>", ' ', u_data) #Remplace les balises par des espaces.
	u_data = re.sub("\s+", ' ', u_data) #Remplace les multiples sauts de ligne/tabulations par des espaces.
	return decode_html_entities(u_data)
