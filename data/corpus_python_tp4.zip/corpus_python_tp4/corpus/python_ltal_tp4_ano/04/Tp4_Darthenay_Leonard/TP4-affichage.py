import zlib
import sys
import glob

def read_file(path_file) :
	f = open(path_file, 'r')
	s = f.read()
	f.close()
	return s

def write_file(path_file, s) :
  f = open(path_file, 'w')
  f.write(s)
  f.close()

def get_header_html() :
  s = '''
  <html>
    <head>
      <meta http-equiv="Content-Type"
            content="text/html; charset=utf-8">
      <title>Titre</title>
    </head>
    <body>
  '''
  return s

def get_footer_html() :
  s = '''
    </body>
  </html>
  '''
  return s

def clean_unicode_html(s_unicode) :
	clean_html = re.sub(u'&nbsp;', ' ', s_unicode)
	clean_html = re.sub(u'[\s]+', u' ', clean_html)
	pattern1 = re.compile(u'<script.+?</script>', re.I | re.M)
	clean_html = pattern1.sub(u'', clean_html)
	pattern2 = re.compile(u'<!\-\-.+?\-\->', re.M)
	clean_html = pattern2.sub(u'', clean_html)
	pattern3 = re.compile(u'<select.+?</select>', re.I | re.M)
	clean_html = pattern3.sub(u'', clean_html)
	pattern4 = re.compile(u'<style.+?</style>', re.I | re.M)
	clean_html = pattern4.sub(u'', clean_html)
	clean_html = re.sub(u'(?:&gt;|&lt;)', u' ', clean_html)
	pattern5 = re.compile(u'[\s]*</*[^>]+/*>[\s]*', re.I | re.M)
	clean_html = pattern5.sub(u'', clean_html)
	pattern6 = re.compile(u'\s[#\s]+', re.I | re.M)
	clean_html = pattern6.sub(u'', clean_html)
	return clean_html


def traitement(path_file):
	src_html = read_file(path_file)
	src_html_unicode = unicode(src_html,"utf-8")
	src_html_unicode = clean_unicode_html(src_html_unicode)
	return src_html_unicode


def distance_info(text1, text2):
	t12 = text1 + text2
	c_t1  = float(len(zlib.compress(text1, zlib.Z_BEST_COMPRESSION)))
	c_t2  = float(len(zlib.compress(text2, zlib.Z_BEST_COMPRESSION)))
	c_t12 = float(len(zlib.compress(t12, zlib.Z_BEST_COMPRESSION)))

	distance =  1 - ((c_t1 + c_t2) - c_t12) / max(c_t1,c_t2)
	return distance


def moyenne_emboiter(chemin, nb_it):
	l = glob.glob(chemin)
	m = {}
	for i, f1 in enumerate(l[:nb_it]) :
		t1 = open(f1, 'r')
		for j, f2 in enumerate(l[:nb_it]):
			t2 = open(f2,'r')
			if i < j :
				continue
			dist = distance_info(t1,t2)
			m[(i,j)] = m[(j,i)] = dist
	return m

def distance_group_min(g1,g2,m):
	l = []
  if isinstance(g1, int) and isinstance(g2,int):
    l.append(m[(g1,g2)])
  elif isinstance(g1, tuple) and isinstance(g2, tuple):
    for i in g1 :
      for j in g2 :
        l.append(m[(i,j)])
  elif isinstance(g1, tuple) and isinstance(g2, int):
    for i in g1:
      l.append(m[(i,g2)])
  elif isinstance(g1, int) and isinstance(g2, tuple):
    for j in g2:
      l.append(m[(g1,j)])
	return min(l)

def distance_group_max(g1,g2,m):
	l = []
  if isinstance(g1, int) and isinstance(g2,int):
    l.append(m[(g1,g2)])
  elif isinstance(g1, tuple) and isinstance(g2, tuple):
    for i in g1 :
      for j in g2 :
        l.append(m[(i,j)])
  elif isinstance(g1, tuple) and isinstance(g2, int):
    for i in g1:
      l.append(m[(i,g2)])
  elif isinstance(g1, int) and isinstance(g2, tuple):
    for j in g2:
      l.append(m[(g1,j)])
	return max(l)
	
def distance_group_moy(g1,g2,m):
	l = []
  if isinstance(g1, int) and isinstance(g2,int):
    l.append(m[(g1,g2)])
  elif isinstance(g1, tuple) and isinstance(g2, tuple):
    for i in g1 :
      for j in g2 :
        l.append(m[(i,j)])
  elif isinstance(g1, tuple) and isinstance(g2, int):
    for i in g1:
      l.append(m[(i,g2)])
  elif isinstance(g1, int) and isinstance(g2, tuple):
    for j in g2:
      l.append(m[(g1,j)])
	u,v=min(li),max(li)
	while len(li)>=2:
		if u!=v and len(li)>5:
			li.remove(u)
			li.remove(u)
			li.remove(v)
			li.remove(v)
			u,v=min(li),max(li)
			print li
		elif u==v and len(li)==4 :
			return u
		else :
			return u


def basemin(dic,l3):
  k=2
  for t in dic:
    if t[0] != t[1]:
      if dic[t] < k:
        k = dic[t]
        tu = t
  l3.append(tu)
  return tu
      
def basemax(dic,l3):
  k=0
  for t in dic:
    if t[0] != t[1]:
      if dic[t] > k:
        k = dic[t]
        tu = t
  l3.append(tu)
  return tu
      

def parcours_elt(tupl, elt):
  a = False
  for t in tupl:
    if t == elt:
      return True
  for t2 in tupl:
    if isinstance(t2, tuple):
      a = parcours_elt(t2, elt)
      if a == True:
        return True
  return a

def remplir_lmin(tupl,l,l2,l3,l4,dic):
  k,tu=2,''
  for t in dic:
    if t not in l3 and (t[1],t[0])not in l3:
      if t[0] != t[1]:
        if (parcours_elt(tupl,t[0])==False) or (parcours_elt(tupl, t[1])==False):
          if dic[t] < k:
            k = dic[t]
            tu = t
  if tu != '':
    l.append(tu)
    l3.append(tu)
  return l

def remplir_lmax(tupl,l,l2,l3,l4,dic):
  k,tu=0,''
  for t in dic:
    if t not in l3 and (t[1],t[0])not in l3:
      if t[0] != t[1]:
        if (parcours_elt(tupl,t[0])==False) or (parcours_elt(tupl, t[1])==False):
          if dic[t] > k:
            k = dic[t]
            tu = t
  if tu != '':
    l.append(tu)
    l3.append(tu)
  return l

def m_e_l(dic,l4):
  for i in dic:
    for j in i:
      if j not in l4:
        l4.append(j)
  return l4

def verifier(tupl,l4):
  for i in l4:
    if parcours_elt(tupl,i) == False:
      return False
  return True

## min ##

def grouper_min(tupl,l,l2,dic):
  if (parcours_elt(tupl, l[1][0]) == True) and (parcours_elt(tupl, l[1][1]) == False):
    g = distance_group_min((l[1][1]),(l[0][0]),m)
    d = distance_group_min((l[1][1]),(l[0][1]),m)
    if g<d:
      tupl = (l[1][1],tupl)
      l = [tupl]
      return tupl, l, l2
    else:
      tupl = (tupl,l[1][1])
      l = [tupl]
      return tupl, l, l2
  elif (parcours_elt(tupl, l[1][0]) == False) and (parcours_elt(tupl, l[1][1]) == True):
    g = distance_group_min((l[1][0]),(l[0][0]),m)
    d = distance_group_min((l[1][0]),(l[0][1]),m)
    if g<d:
      tupl = (l[1][0],tupl)
      l = [tupl]
      return tupl, l ,l2
    else:
      tupl = (tupl,l[1][0])
      l = [tupl]
      return tupl, l, l2
  else:
    l2.append(l[-1])
    l.remove(l[-1])
    return tupl, l, l2


def groupermin(tupl, l, l2,l3,l4,dic):
  remplir_lmin(tupl,l,l2,l3,l4,dic)
  if l2 == []:
    tupl,l,l2 = grouper_min(tupl,l,l2,dic)
  else:
    tupl,l,l2 = grouper_2min(tupl,l,l2,dic)
  return tupl, l

    

def grouper_2min(tupl,l,l2,dic):
  for i in l2:
    if (parcours_elt(i, l[1][0])==True):
      if (parcours_elt(tupl, l[1][0]) == False):
        tupl = (tupl,i)
        l2.remove(i)
        l.remove(l[-1])
        l=[tupl]
        return tupl,l,l2

    elif (parcours_elt(i, l[1][1])==True):
      if (parcours_elt(tupl, l[1][1]) == False):
        tupl = (tupl,i)
        l2.remove(i)
        l.remove(l[-1])
        l=[tupl]
        return tupl,l,l2
    else:
      l2.append(l[1])
      l.remove(l[1])
      return tupl, l , l2

## max ##

def grouper_max(tupl,l,l2,dic):
  if (parcours_elt(tupl, l[1][0]) == True) and (parcours_elt(tupl, l[1][1]) == False):
    g = distance_group_max((l[1][1]),(l[0][0]),m)
    d = distance_group_max((l[1][1]),(l[0][1]),m)
    if g>d:
      tupl = (l[1][1],tupl)
      l = [tupl]
      return tupl, l, l2
    else:
      tupl = (tupl,l[1][1])
      l = [tupl]
      return tupl, l, l2
  elif (parcours_elt(tupl, l[1][0]) == False) and (parcours_elt(tupl, l[1][1]) == True):
    g = distance_group_max((l[1][0]),(l[0][0]),m)
    d = distance_group_max((l[1][0]),(l[0][1]),m)
    if g>d:
      tupl = (l[1][0],tupl)
      l = [tupl]
      return tupl, l ,l2
    else:
      tupl = (tupl,l[1][0])
      l = [tupl]
      return tupl, l, l2
  else:
    l2.append(l[-1])
    l.remove(l[-1])
    return tupl, l, l2


def groupermax(tupl, l, l2,l3,l4,dic):
  remplir_lmax(tupl,l,l2,l3,l4,dic)
  if l2 == []:
    tupl,l,l2 = grouper_max(tupl,l,l2,dic)
  else:
    tupl,l = grouper_2max(tupl,l,l2,dic)
  return tupl, l

    

def grouper_2max(tupl,l,l2,dic):
  for i in l2:
    if (parcours_elt(i, l[1][0])==True):
      if (parcours_elt(tupl, l[1][0]) == False):
        tupl = (tupl,i)
        l2.remove(i)
        l.remove(l[-1])
        l=[tupl]
        return tupl,l
    elif (parcours_elt(i, l[1][1])==True):
      if (parcours_elt(tupl, l[1][1]) == False):
        tupl = (tupl,i)
        l2.remove(i)
        l.remove(l[-1])
        l=[tupl]
        return tupl,l
        

def detuplage(tup):
	li = []
	if isinstance(tup,tuple):
		li = li +detuplage(tup[0])+detuplage(tup[1])
	else :
		return [tup]
	return li
			

def casecolor(elt, nb_class):
	u = int(120 / nb_class)
	valcoul = 0
	listecoul = []
	while valcoul <= 120 :
		listecoul += [valcoul]
		valcoul += u
	part = 1. / nb_class
	val = int(elt / part)
	couleur = listecoul[val]
	return couleur

def tableur(g, m, nb_class):
	text = "<div><table>"
	ch = 1
	for i in g :
		text = text + "\n<tr>"
		for j in g :
			color = casecolor(m[(i,j)], nb_class)
			text = text +'\n<td style="background-color:hsl('+str(color)+', 100%, 50%);">'+str(m[(i,j)])+'</td>'
		text = text +'<td>'+str(ch)+'</td>'+"\n"
		ch = ch + 1
		text = text + "</tr>"
	text = text + "\n<tr>"
	ch = 1
	for i in g :
		text = text + "<td>"+str(ch)+"</td>"
		ch = ch + 1
	text = text + "</tr>"
	ch = 1
	text = text +"<div>\n"
	for i in g :
		text = text +"<p>"+ str(ch) +" : "+str(i)+"</p>\n"
		ch = ch + 1
	text = text +"</div>"
	return text

################ test
a = tableur(["truc","machin","bidule"], {("truc","truc") : 0, ("truc","bidule") : 0.3, ("truc","machin") : 0.7, ("bidule","truc") : 0.3, ("bidule","bidule") : 0, ("bidule","machin") : 0.5, ("machin","truc") : 0.7, ("machin","bidule") : 0.5, ("machin","machin") : 0} , 12)


text = get_header_html() +a+ get_footer_html()

print text

text = text.encode('UTF-8')

write_file("new.html",text)
################

if __name__ == '__main__' :
	corpus_a_analyser = sys.argv[1]
	distance = sys.argv[2]
	nb_classe = sys.argv[3]

	for chemin in glob.glob("%s*/"%(corpus_a_analyser)):
		for fichier in glob.glob("%s*"%(chemin)):
			text = traitement(fichier)
			text = text.encode("UTF-8")
			write_file("corpusencours/text_"+str(i)+".txt", text)
	dic_matrice = moyenne_emboiter("Corpus_Entrainement/corpusencours/", 5)
