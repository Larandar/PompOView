
import zlib,glob,re


def read_file(path_file) :
  f = open(path_file, 'r')
  s = f.read()
  f.close()
  return s

def clean_unicode_html(s_unicode) :
  clean_html = re.sub(u'&nbsp;', ' ', s_unicode)
  clean_html = re.sub(u'[\s]+', u' ', clean_html)

  pattern1 = re.compile(u'<script.+?</script>', re.I | re.M)
  clean_html = pattern1.sub(u'', clean_html)

  pattern2 = re.compile(u'<!\-\-.+?\-\->', re.M)
  clean_html = pattern2.sub(u'', clean_html)

  pattern3 = re.compile(u'<select.+?</select>', re.I | re.M)
  clean_html = pattern3.sub(u'', clean_html)

  pattern4 = re.compile(u'<style.+?</style>', re.I | re.M)
  clean_html = pattern4.sub(u'', clean_html)

  clean_html = re.sub(u'(?:&gt;|&lt;)', u' ', clean_html)

  pattern5 = re.compile(u'[\s]*</*[^>]+/*>[\s]*', re.I | re.M)
  clean_html = pattern5.sub(u' # ', clean_html)

  pattern6 = re.compile(u'\s[#\s]+', re.I | re.M)
  clean_html = pattern6.sub(u' # ', clean_html)
  
  return clean_html


def prepare_file(path_file) :
  chaine_complete = read_file(path_file)
  chaine_complete = unicode(chaine_complete,'utf-8')
  chaine_propre = clean_unicode_html(chaine_complete)
  return chaine_propre





def concatenation (d2,d1) :
  for mot in d2:
    if d1.has_key(mot) :
      d1[mot] = d1[mot]+d2[mot]
    else:
      d1[mot] = d2[mot]
  return d1


##################### Calcul de la distance #####################

def compute_inf_dist(text1, text2):
    t12 = text1 + text2
    c_t1  = float(len(zlib.compress(text1, zlib.Z_BEST_COMPRESSION)))
    c_t2  = float(len(zlib.compress(text2, zlib.Z_BEST_COMPRESSION)))
    c_t12 = float(len(zlib.compress(t12, zlib.Z_BEST_COMPRESSION)))

    distance =  1 - ((c_t1 + c_t2) - c_t12) / max(c_t1,c_t2)
    return distance


def calcul_distance (fichier) :
  d = {}
  d2 = {}
  r = glob.glob(fichier)
  for filename1 in r :
    filename1bis = prepare_file(filename1)
    filename1bis = filename1bis.encode('utf-8')
    for filename2 in r :
      filename2bis = prepare_file(filename2)
      filename2bis = filename2bis.encode('utf-8')
      distance = compute_inf_dist(filename1bis,filename2bis)
      d2[filename1,filename2] = distance
  d = concatenation (d,d2)
  #d = TrierDico (d)
  return d

def dendrogramme (f1,f2) :
  pass
    

def TrierDico (dico) :
  items = dico.items ()
  comparateur = lambda a,b : cmp (a[1],b[1])
  return type,sorted(items, comparateur, reverse = True)



 
def tableau () :
  d = calcul_distance (fichier)
  
def main (fichier) :
  d = calcul_distance(fichier)
  return d


##################### Definition d'une matrice ##################

##m = matrice
##def min-g(g1,g2,m)
##	d=2.
##	for x in g1:
##		for y in g2:
##			if x<y
##				y,x=x,y
##			dist=m[(x,y)]
##

