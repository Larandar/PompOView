# -*- coding: UTF-8 -*-

import simil as simil
import glob
import sys

def DistanceCorpus(path):
  listFileName = []
  matrice = []

  for nm in glob.glob(path):
    listFileName += [nm]

  for i in listFileName:
    a = []
    for j in listFileName:
      a.append( ((i, j), simil.distance(i, j) ) )
      #a.append( ((i, j), simil.jw(i, j) ) )
    matrice.append( a )

  return matrice

def parcoursProf(den, pile):
  if type(den)==tuple:
    if type(den[0][0])==str:
      pile.append( ((den[0][0], den[0][1]), den[1]) )
      return pile
    else:
      for i in range(len(den[0])):
        pile = parcoursProf(den[0][i], pile)
  elif type(den)==list:
    pile = parcoursProf(den[0], pile)
  return pile

def mini(a, b):
  if a < b:
    return a
  return b

def moyn(a, b):
  return( float( (a+b))/float(2 ) )

def maxi(a, b):
  if a > b:
    return a
  return b

def preDendro( matrice ):
  work = []
  for i in range(0, len(matrice) ):
    for j in range(i+1, len(matrice[i]) ):
      work.append( (matrice[i][j]) )
  return work

def maxDendrogramme(work):
  while len( work )!=1:
    n, m = 1, 0
    pos_i, pos_j = 0, 0
    for i in range(0, len(work) ):
      for j in range(0, len(work) ):
        if abs( float(work[i][1]) - float(work[j][1]) ) < n and i!=j:
          m = maxi(work[i][1], work[j][1])
          n = abs( float(work[i][1]) - float(work[j][1]) )
          pos_i = i
          pos_j = j

    work[pos_i] = (work[pos_i], work[pos_j]), m
    work.__delitem__(pos_j)
  return work

def moyDendrogramme(work):
  while len( work )!=1:
    n, m = 1, 0
    pos_i, pos_j = 0, 0
    for i in range(len(work) ):
      for j in range(len(work) ):
        if abs( float(work[i][1]) - float(work[j][1]) ) < n and i!=j:
          n = abs( float(work[i][1]) - float(work[j][1]) )
          m = moyn(work[i][1], work[j][1])
          pos_i = i
          pos_j = j

    work[pos_i] = (work[pos_i], work[pos_j]), m
    work.__delitem__(pos_j)
  return work

def minDendrogramme(work):
  while len( work )!=1:
    n, m = 1, 0
    pos_i, pos_j = 0, 0
    for i in range( len( work ) ):
      for j in range( len( work ) ):
        if i!=j:
          if abs( float(work[i][1]) - float(work[j][1]) ) < n:
            m = mini(work[i][1], work[j][1])
            n = abs( float(work[i][1]) - float(work[j][1]) )
            pos_i = i
            pos_j = j
    work[pos_i] = (work[pos_i], work[pos_j]), m
    work.__delitem__(pos_j)
  return work


#####
    
def MatriceVide(n):
    matrice = [0] * n

    for i in range(0, n):
        matrice[i] = [0] * n

    return( matrice )

def DisplayMatrice( data1, data2 ):
  sz = len(data2)
  matrice = MatriceVide( sz + 1 )
  n = 0

  done = []
  preMat = []
  for i in range( len(data1) ):
    if done.__contains__(data1[i][0][0])==False:
      done.append( data1[i][0][0] )
      value = []
      for j in range( len(data1) ):
        if data1[i][0][0]==data1[j][0][0]:
          value.append( data1[j][1] )
      preMat.append( (done[len(done)-1], value) )

  for i in range( len(data1) ):
    if done.__contains__(data1[i][0][1])==False:
      lastElement = data1[i][0][1]

  for i in preMat:
    rang = sz - len(i[1])
    n = 0
    for j in range( len(i[1]) ):
      matrice[rang][sz-j-1] = i[1][n]
      matrice[sz-j][rang-1] = i[1][n]
      n+=1
    matrice[rang][sz] = i[0]
    matrice[0][rang-1] = i[0]

  matrice[0][sz-1] = lastElement
  matrice[sz][sz] = lastElement


  #Diagonal
  for i in range( sz ):
    matrice[i+1][i] = simil.distance(matrice[0][i], matrice[0][i])

  val = []
  for i in range(1, sz ):
    for j in range( i, sz ):
      if val.__contains__(matrice[i][j])==False:
        val.append(matrice[i][j])

  val.sort()

  return val, matrice

def subdiv(l, v):
    res = []
    for i in range( v ):
        somme = 0
        n = 0
        for k in l[i*(len(l)/v):(i+1)*len(l)/v]:
            somme+=k
            n+=1
        m = float(somme)/float(n)
        res.append( m )
    if v==2:
        somme = 0
        for i in l:
            somme+=i
        res.append(float(somme)/float( len( l ) ) )
        res.sort()
    return res

def sFormat( s ):
  r = '<p style="font-size:10px;">'
  for i in range( len(s) ):
    r+=s[i]+'<br />'
  r+='</p>'
  return r

def cmpval(x,y) :
    return y[1] - x[1]

def doColor(value, div):
  res = []
  r = subdiv( value, div )
  for i in range( len(r) ):
    res.append( (value[i], (120 / len(r)) * i) )
  res.sort(cmpval)
  return res

def getColor(c_list, r):
  if r < 0.5:
    return 0
  for i in range( len(c_list) ):
    if r > c_list[i][0] and r < 1:
      color = c_list[i][1]
      return color
  return 120

def HTMLdisplay(htmlFile, matrice, color):
  f = open(htmlFile, "w")
  s = ''
  f.write('<html><head></head><body><table style="font-size:12px;">')
  for i in range(1, len(matrice) ):
    f.write('<tr>')
    for j in range( len(matrice[i]) - 1 ):
      c = getColor(color, matrice[i][j])
      s += "<td style=\"background-color:hsl("+str(c)+" , 100%, 50%);\">"+str(matrice[i][j])+"</td>"
    s+='<td><p style="font-size:10px;">'+(matrice[i][len(matrice)-1])+'</p></td>'
    f.write( s )
    s = ''
    f.write('</tr>')
  f.write('<tr>')
  for i in range( len(matrice) - 1):
    q = '<td>'
    q+= sFormat(matrice[0][i])
    q+= '</td>'
    f.write(q)
  f.write('</tr></table>')
  f.write('</body></html>')
  f.close()

### [MAIN] ###
if __name__=='__main__' :
  corpus = sys.argv[1] + '/*.*'
  dist = sys.argv[2]
  div = sys.argv[3]

  m = DistanceCorpus(corpus)
  q = preDendro( m )

  if dist=='min':
    k = minDendrogramme( q )
  elif dist=='moy':
    k = moyDendrogramme( q )
  else:
    k = maxDendrogramme( q )

  a = parcoursProf( k, [] )
  val, x = DisplayMatrice(a, m)

  if float(div)/float(len(val)) > 0.75:
    print "La valeur du nombre de classes doit être inferieur à ", div
    exit

  c = doColor(val, int(div) )
  out = corpus.replace('/', '_')
  out = out.replace('*', '')
  out = out.replace('.', '')
  out+=dist+'_out.html'
  HTMLdisplay(out, x, c)

