# -*- coding: UTF-8 -*-
#Calcul des distances
#compréssées

import os
import zlib

#Lire un fichier entier
def read_file(path_file) :
  f = file(path_file, 'r')
  s = f.read()
  f.close()
  return s

#Ecrire un buffer netier dans un fichier
def write_file(path_file, s) :
  f = open(path_file, 'w')
  f.write(s)
  f.close()

#concatener deux fichiers
def concatenat( file1, file2 ):

  cn1 = read_file(file1)
  cn2 = read_file(file2)

  cn = ('%s%s')%(cn1, cn2)
  
  return cn

#max de a et b
def maxi(a, b):
  if a > b:
      return a
  return b

#min de a et b
def mini(a, b):
  if a < b:
      return a
  return b

#calcul la distance entre deux fichiers par compression
def distance(f1, f2):
  c1 = read_file(f1)
  c2 = read_file(f2)

  c3 = concatenat(f1, f2)

  c_c1 = zlib.compress(c1)
  c_c2 = zlib.compress(c2)
  c_c3 = zlib.compress(c3)

  d = 1 - ( len(c_c1) + len(c_c2) - len(c_c3) )/float( maxi( len(c_c1), len(c_c2) ) )
  return round(d, 2)

#Distance de Jaro
def jw(f1, f2):
    s1 = read_file( f1 )
    s2 = read_file( f2 )

    sz_1 = len( s1 )
    sz_2 = len( s2 )

    accept = ( maxi(sz_1, sz_2) / 2 ) - 1

    n, m, t = 0, 0, 0
    while n < mini(sz_1, sz_2):
        if s1[n]==s2[n]:
            m += 1
        else:
            if accept + n < mini(sz_1, sz_2):
                for d in range(n+1, accept):
                    if s1[n]==s2[d]:
                        m +=1
            t+=1
        n+=1
    t = (t/2.0)
    if m > 0:
        return abs(( 1/3 * (m/float(sz_1)) + (m/float(sz_2)) + abs((m-t))/float(m) )-1)
    return abs( 1/2 * (m/float(sz_1)) + (m/float(sz_2)) )

