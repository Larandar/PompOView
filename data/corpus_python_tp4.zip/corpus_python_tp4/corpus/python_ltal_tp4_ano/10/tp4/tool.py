#!/usr/local/bin/pythonw
# -*- coding: utf-8 -*-
import re, os,string,htmlentitydefs
def file_read(path_file): 
    fichier=open(path_file,"r")
    chaine = fichier.read()
    fichier.close()
    return chaine
    
def file_write(path_file,chaine):
	fichier=open(path_file,"w")
	fichier.write(chaine)
	fichier.close()		
	

def unicode_chaine(chaine_html,codage):
	chaine=unicode(chaine_html,codage)
	return chaine
	
	
def clean_unicode_html(chaine_html_unicode):
  clean_html = re.sub(u'&nbsp;', ' ', chaine_html_unicode)
  clean_html = re.sub(u'[\s]+', u' ', clean_html)

  pattern0 = re.compile(u'<script.+?</script>', re.I | re.M)
  clean_html = pattern0.sub(u'', clean_html)

  pattern1=re.compile(u'<noscript.+?</noscript>', re.I | re.M)
  clean_html = pattern1.sub(u'', clean_html)
  
  pattern2 = re.compile(u'<!\-\-.+?\-\->', re.M)
  clean_html = pattern2.sub(u'', clean_html)
  
  pattern3 = re.compile(u'<select.+?</select>', re.I | re.M)
  clean_html = pattern3.sub(u'', clean_html)
  

  pattern4 = re.compile(u'<style.+?</style>', re.I | re.M)
  clean_html = pattern4.sub(u'', clean_html)

  clean_html = re.sub(u'(?:&gt;|&lt;)', u' ', clean_html)

  pattern5 = re.compile(u'[\s]*</*[^>]+/*>[\s]*', re.I | re.M)
  clean_html = pattern5.sub(u'', clean_html)

  pattern6 = re.compile(u'\s[#\s]+', re.I | re.M)
  clean_html = pattern6.sub(u'', clean_html)
  return clean_html
  
def decode_html_entities(s_unicode) :
  #see :: def replace_num_entities()
  html = re.sub(u'&#([0-9]+);', replace_num_entities, s_unicode)
  pattern = re.compile(u'&([a-z]+);', re.I)
  #see :: def replace_alpha_entities()
  html = pattern.sub(replace_alpha_entities, html)
  return html
  
def replace_num_entities(matchobj_unicode) :
  if int(matchobj_unicode.group(1)) in range(65535):
    return unichr(int(matchobj_unicode.group(1)))
  else:
    return u'&#%s;'%(matchobj_unicode.group(1))

def replace_alpha_entities(matchobj_unicode) :
  k = matchobj_unicode.group(1)
  if not htmlentitydefs.entitydefs.has_key(k) :
    if k.isupper() :
      k = string.lower(matchobj_unicode.group(1))
      if not htmlentitydefs.entitydefs.has_key(cle) :
        return ''
    else :
      return ''
  if len(htmlentitydefs.entitydefs[k]) == 1 :
    car = htmlentitydefs.entitydefs[k]
    return unicode(car, 'iso-8859-1') #  car est codé en 'iso-8859-1' --> entitydefs[name] = chr(codepoint) dans htmlentitydefs
  else :
    str_code = htmlentitydefs.entitydefs[k].strip(u'&#;')
    return unichr(int(str_code))
			
			
def prepare_file(path_file,type_corpus):
	chaine_html=file_read(path_file)
	if type_corpus == "python":
		return chaine_html
	if type_corpus == "html":
		chaine_html_unicode=unicode_chaine(chaine_html,"utf-8")
		clean_html=clean_unicode_html(chaine_html_unicode)
		clean_html=decode_html_entities(clean_html)
		clean_html=clean_html.encode('utf-8')
		return clean_html
	
	

	
def first_line_html(liste_parcour_profondeur):
	res='''
	<table width="20%" style="font-size:9px;  style="collapse:collapse;" cellspacing="0">
		<tr> 
			<td>&nbsp;</td>
		'''
	for x in liste_parcour_profondeur:
		res+='''
			<td align="center" >%s</div></td>
			'''%(x)
	res+='''
		</tr>
		'''
	return res


def get_header_html() :
  return '''
  <html>
    <head>
      <meta http-equiv="Content-Type"
            content="text/html; charset=utf-8">
      <title>Titre</title>
    </head>
    <body>
  '''

def get_footer_html() :
  return '''
    </body>
  </html>
  '''
	
  
def first_line_tex(liste_parcour_profondeur,name_variable_tex):
	res='''
\\begin{landscape}
\hspace{-4cm}
\scalebox{0.4}{'''
	tabular=''
	line='   '
	for x in liste_parcour_profondeur:
		tabular+='|c'
		line+=' & %s'%(name_variable_tex(x))
	tabular+='|'
	res+=''' 
	\\begin{tabular}{|c%s}'''%(tabular)
	res+='''
		\hline
		%s \\\\'''%(line)
	return res
	
	
def get_header_tex() :
  return '''
\documentclass{article}
\usepackage[francais]{babel}
\usepackage[utf8]{inputenc}
\usepackage[T1]{fontenc}
\usepackage[table]{xcolor}
\usepackage{lscape}
\usepackage{graphicx}

\\begin{document}


  '''


def get_footer_tex() :
  return '''

\end{landscape}
\end{document}
  '''

def genere_dessine_dendrogramme(matrice,x,y,longueur,test):
	if not isinstance(matrice,list):
		return '''
		\put(%f,-90){\line(0,1){%f}}	
		\put(%f,-100){\\textbf{%s}}'''%(x,y+120,x-10,matrice)
	else:
		graph='''
		\put(%f,%f){\line(0,1){30}}
		\put(%f,%f){\line(1,0){%f}}
		'''%(x,y,test,y,longueur)+genere_dessine_dendrogramme(matrice[0],float(x/2),y-30,float(longueur/2),float(test/2))+genere_dessine_dendrogramme(matrice[1],x+float(longueur/2),y-30,float(longueur/2),longueur+float(test/2))
	return graph

def dessine_dendrogramme(matrice,x,y,longueur,test):
	t='''\\begin{picture}(0,0)'''+genere_dessine_dendrogramme(matrice,x,y,longueur,test)+'''
	\end{picture}'''
	res= get_header_tex()+t+'''
	\end{document}'''
	file_write("dendrogramme.tex",res)
