#!/usr/local/bin/pythonw
# -*- coding: utf-8 -*-

import zlib,glob,sys,os,sys
import tool as tl


def distance_info(text1, text2):
    t12 = text1 + text2
    c_t1  = float(len(zlib.compress(text1, zlib.Z_BEST_COMPRESSION)))
    c_t2  = float(len(zlib.compress(text2, zlib.Z_BEST_COMPRESSION)))
    c_t12 = float(len(zlib.compress(t12, zlib.Z_BEST_COMPRESSION)))

    distance =  1 - ((c_t1 + c_t2) - c_t12) / max(c_t1,c_t2)
    return distance
    
def generer_matrice(liste_element_dossier,type_corpus):
	liste_distance=[]
	for i,f1 in enumerate(liste_element_dossier):
		texte1_clean=tl.prepare_file(f1,type_corpus)
		for j,f2 in enumerate(liste_element_dossier):
			if i<j or i==j:
				continue
			texte2_clean=tl.prepare_file(f2,type_corpus)
			liste_distance+=[[distance_info(texte1_clean,texte2_clean),[f1,f2]]]

		
	return liste_distance	

def search_min_distance(matrice):
	mini=1#initialiser a 1 car distance < 1 
	cluster_min=[]
	for i in xrange(len(matrice)):
		if matrice[i][0]<mini:
			mini = matrice[i][0]
			cluster_min = matrice [i][1]
	return mini , cluster_min
			
def del_element_matrice(element,matrice_dep):
	matrice=matrice_dep[:]
	for x in matrice_dep:
		if x[1] == element :
			matrice.remove(x)
		elif x[1][0] == element[0] or x[1][0] == element[1] or x[1][1] == element[0] or x[1][1] == element[1]:
			matrice.remove(x)
	return matrice

def recalcule_distance(matrice,element,matrice_dep,liste_texte,type_d):
	new_cluster=[]
	for x in liste_texte:
		if x!=element: 
			cluster=[element,x]
			if type_d=='min':
				distance=min(search_distance_element(x,element[0],matrice_dep),search_distance_element(x,element[1],matrice_dep))
			if type_d=='max':
				distance=max(search_distance_element(x,element[0],matrice_dep),search_distance_element(x,element[1],matrice_dep))
			if type_d=='moy':
				distance=float((search_distance_element(x,element[0],matrice_dep)+search_distance_element(x,element[1],matrice_dep))/2)
			new_cluster+=[[distance,cluster]]
	matrice.extend(new_cluster)
	return matrice
		
def search_distance_element(y,element,matrice):
	for x in matrice:
		if x[1]==[y,element] or x[1]==[element,y]:
			return x[0]	
	

def liste_element(liste_texte,element):
	liste_traitement=liste_texte[:]
	liste_traitement.append(element)
	for x in liste_texte:
		if x == element[0] or x == element[1]:
			liste_traitement.remove(x)
	liste_texte=liste_traitement[:]
	return liste_texte

def dendrogramme(matrice,liste_texte,type_d):
	matrice_dep=matrice[:]
	liste_texte=liste_texte[:]
	while len(matrice_dep)>1:
		min_cluster=search_min_distance(matrice_dep)[1]
		liste_texte=liste_element(liste_texte,min_cluster)
		matrice_copy=del_element_matrice(min_cluster,matrice_dep)
		matrice_end=recalcule_distance(matrice_copy,min_cluster,matrice_dep,liste_texte,type_d)
		matrice_dep=matrice_end
	return matrice_end

def parcour_profondeur(matrice):
	if not isinstance(matrice,list):
			return [matrice]
	else:
		liste_element_ordonne=parcour_profondeur(matrice[0])+parcour_profondeur(matrice[1])
	return liste_element_ordonne
	
def name_variable_tex(variable):
	for i in xrange(len(variable)):
		if variable[i] == '_':
			variable=variable[:i-1]+'\\'+variable[i:]
	return variable
def other_line_html(liste_parcour_profondeur,matrice_dist,liste_moyenne,nb):
	res='''
		'''
	for x in liste_parcour_profondeur:
		res+='''
		<tr>
			<td align="center">%s</div></td>
			'''%(x)
		for y in liste_parcour_profondeur:
			if x==y:
				res+='''
			<td style="background-color:hsl(0,100%%,50%%); align="center">%f</div></td>
				'''%(0)
			else:
				d=search_distance_element(x,y,matrice_dist)
				res+='''
			<td style="background-color:hsl(%s,100%%,50%%); align="center">%f</div></td>
				'''%(hsl_color(d,liste_moyenne,nb),d)
		res+='''
		</tr>
			'''
	res+='''
	</table>
	'''
	return res	

def other_line_tex(liste_parcour_profondeur,matrice_dist,liste_moyenne,nb):
	res='''
		'''
	for x in liste_parcour_profondeur:
		res+='''
		\hline
		%s '''%(name_variable_tex(x))
		for y in liste_parcour_profondeur:
			if x==y:
				res+=' & \cellcolor[hsb]{0.0, 0.70, 0.90} %s '%(0)
			else:
				d=search_distance_element(x,y,matrice_dist)
				res+=' & \cellcolor[hsb]{%f, 0.70, 0.90} %s '%(hsl_color(d,liste_moyenne,nb)/360.,round(d,2))
		res+=' \\\\'
	res+='''
		\hline
	 \end{tabular}}'''
	return res
		
def moyenne_emboitee(liste,nb_it):
	if nb_it==0 :
		return liste
	res=0
	for x in liste:
		res+=x
	
	liste1=[x for x in liste if  x<(res/len(liste))]
	
	liste2=[x for x in liste if x>=(res/len(liste))]

	return [moyenne_emboitee(liste1,nb_it-1),moyenne_emboitee(liste2,nb_it-1)]	
	
def search_color_position(matrice,d,pos,nb):
	if matrice!=[] or matrice!=[]:
		if not isinstance(matrice[0],list) or not isinstance(matrice[1],list):
			if d in matrice:
				return pos+1

		else:	
			return search_color_position(matrice[0],d,pos,nb-1) or search_color_position(matrice[1],d,pos+2**nb,nb-1)

def hsl_color(d,liste_moyenne,nb):
	pos=0
	position_categorie=search_color_position(liste_moyenne,d,pos,nb-1)-1
	return (120/(2**nb))*position_categorie
	
def recupere_liste_distance(matrice):
	l=[]
	for x in matrice :
		l+=[x[0]]
	return l
def main(dossier,type_d,nb_it,type_corpus,type_output):
	liste_texte=glob.glob("%s*"%(dossier))
	matrice=generer_matrice(liste_texte,type_corpus)
	liste_distance=recupere_liste_distance(matrice)
	m_emboite= moyenne_emboitee(liste_distance,nb_it)
	liste_dendrogramme=dendrogramme(matrice,liste_texte,type_d)[0][1]
	liste_element_ordonne=parcour_profondeur(liste_dendrogramme)
	#tl.dessine_dendrogramme(liste_dendrogramme,200,0,200,100) # Ne fonctionne que sur certain arbre , probléme dans les coordonées 
	if type_output == 'html':
		matrice_output=tl.get_header_html()+tl.first_line_html(liste_element_ordonne)+other_line_html(liste_element_ordonne,matrice,m_emboite,nb_it)+tl.get_footer_html()
		tl.file_write("matrice.html",matrice_output)
	if type_output == 'tex':
		matrice_output=tl.get_header_tex()+tl.first_line_tex(liste_element_ordonne,name_variable_tex)+other_line_tex(liste_element_ordonne,matrice,m_emboite,nb_it)+tl.get_footer_tex()
		tl.file_write("matrice.tex",matrice_output)
	
								
if __name__=='__main__' :
	dossier=sys.argv[1]
	type_corpus=sys.argv[2]
	nb_it=int(sys.argv[3])
	type_d=sys.argv[4]
	type_output=sys.argv[5]
	main(dossier,type_d,nb_it,type_corpus,type_output)
	
