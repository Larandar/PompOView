import sys
import re
import glob
import zlib


def read_file(path_file) :
  f = open(path_file, 'rb')
  s = f.read()
  f.close()
  return s

def write_file(path_file, s) :
  f = open(path_file, 'w')
  f.write(s)
  f.close()

def clean_html(html):
	pattern5 = re.compile(u'[\s]*</*[^>]+/*>[\s]*', re.I | re.M)
 	clean_html = pattern5.sub(u'',html)
	return clean_html

def clean_codesource(source):
	pattern5 = re.compile(u'[\s]*', re.I | re.M)
 	clean_source = pattern5.sub(u' ',source)
	return clean_source

def comp_dist(text1, text2):
    t12 = text1 + text2
    c_t1  = float(len(zlib.compress(text1, zlib.Z_BEST_COMPRESSION)))
    c_t2  = float(len(zlib.compress(text2, zlib.Z_BEST_COMPRESSION)))
    c_t12 = float(len(zlib.compress(t12, zlib.Z_BEST_COMPRESSION)))

    distance =  1 - ((c_t1 + c_t2) - c_t12) / max(c_t1,c_t2)
    return round(distance, 2)


def compare(file1,file2):
	file1=read_file(file1)
        file2=read_file(file2)
	if file1[-3:] == 'xml':
		file1=unicode(file1,"utf-8")
		file2=unicode(file2,"utf-8")
		file1=clean_html(file1)
		file2=clean_html(file2)
	else:
		file1=unicode(file1,"utf-8")
		file2=unicode(file2,"utf-8")
		file1=clean_codesource(file1)
		file2=clean_codesource(file2)
	file1=file1.encode("utf-8")
	file2=file2.encode("utf-8")
	dist=comp_dist(file1,file2)
	return dist

def matrice_dist(folder):
	mat={}
	for name1 in glob.glob("%s/*"%(folder)):
		for name2 in glob.glob("%s/*"%(folder)):
			if name1 != name2 and name1 < name2:
				dist=compare(name1,name2)
				mat[(name1,name2)]=dist
	return mat




def min_g(g1,g2,m):
	d=2 # Valeur max de la distance informationelle
	for x in g1:
		for y in g2:
			if x < y and x != y:
				dist=m[(x,y)]
			elif x > y and x != y:
				dist=m[(y,x)]
			else:
				dist=2
			if dist < d:
				d=dist
	return d

def max_g(g1,g2,m):
	d=-1 #Valeur min 
	for x in g1:
		for y in g2:
			if x < y and x != y:
				dist=m[(x,y)]
			elif x > y and x != y:
				dist=m[(y,x)]
			else:
				dist = -1
			if dist > d:
				d=dist
	return d



def avg_g(g1,g2,m):
	diff=100
	total=0
	for (x,y) in m:
		total+=m[(x,y)]
	moy=total/len(m)
	for x in g1:
		for y in g2:
			if x < y and x != y:
				dist=m[(x,y)]
			elif x > y and x != y:
				dist=m[(y,x)]
			else:
				d_dif = 0
			if dist < moy:
				d_dif=moy-dist
			else:
				d_dif=dist-moy
			print d_dif
			if d_dif < diff:
				d=dist
	return d

def untuple(t_uple):
	res=""
	for x in t_uple:
		if type(x) is not tuple:
			Docs=read_file(x)
			Docs=unicode(Docs,"utf-8")
			Docs=clean_html(Docs)
			Docs=Docs.encode("utf-8")
			res+=Docs
		else:
			inter=untuple(x)
			res+=inter
	return res
			


def endo_min(g1,g2,matrice,res,dist_type):
	new_mat={}

###############Min/Max/Avg############
	if dist_type == "min" :
		min_dist=min_g(g1,g2,matrice)
		res.append((min_dist))
		for x,y in matrice:
			if matrice[x,y] == min_dist:
				dx = x
				dy = y
			
	elif dist_type == "max":
		max_dist=max_g(g1,g2,matrice)
		res.append((max_dist))
		for x,y in matrice:
			if matrice[x,y] == max_dist:
				dx = x
				dy = y

	else:
		avg_dist=avg_g(g1,g2,matrice)
		print avg_dist
		res.append((avg_dist))
		for x,y in matrice:
			if matrice[x,y] == avg_dist:
				dx = x
				dy = y
######################################


########################Groupe########################
	groupe_inter=[]
	for x in g1:
		if x != dx and x != dy:
			groupe_inter.append(x)
	groupe_inter.append((dx,dy))
	g1=groupe_inter
	g2=groupe_inter

######################################################

#####################Modif mat########################
	for docs in g1:
		for docs_2 in g2:
			if docs != docs_2 and docs < docs_2:
				if type(docs) is not tuple and type(docs_2) is not tuple:
					dist=compare(docs,docs_2)
				elif type(docs) is not tuple and type(docs_2) is tuple:
					main_2=""
					Docs=read_file(docs)
					Docs=unicode(Docs,"utf-8")
					Docs=clean_html(Docs)
					Docs=Docs.encode("utf-8")
					main_2=untuple(docs_2)
					dist=comp_dist(Docs, main_2)
				else:
					main_1=untuple(docs)
					main_2=untuple(docs_2)
					dist=comp_dist(main_1, main_2)
				new_mat[docs,docs_2]=dist
######################################################
	if len(g1) > 1:
		endo_min(g1,g2,new_mat,res,dist_type)
	return res

			
			
def entangled_mean(l,n):
	if l != []:
		moy=sum(l)/len(l)
		lg,ld=[],[]
		res=[]
		for x in l:
			if x < moy:
				lg+=[x]
			else:
				ld+=[x]
		res = [lg]+[ld]
		while n > 1:
			if lg != [] and ld != []:
				res=entangled_mean(lg,n-1)+entangled_mean(ld,n-1)
			n=n-1
	return res

#def sort(matrice):
#	mat_sorted=[]
#	for x,y in matrice:
#		mat_sorted.append(((x,y),matrice[x,y]))
#	return mat_sorted
	


def affichage(g1,g2,matrice,endo,color):
	col_ratio=120/(len(color)+1)
	tab_start='''
	<table style="collapse:collapse;" cellspacing="0">
		<tr>
	'''
	tab_end='''
		</tr>
	</table>
	'''
	for x in g1:
		for y in g2:
			if x == y:
				s=0
				tab_start+='''<td style="font-size:11px;padding:2px;background-color:hsl(0, 100%, 50%);">'''
				tab_start+='''%d</td>'''%(s)
			elif (x,y) not in matrice:
				indi = 1
				s=matrice[y,x]
				for i in range(len(color)):
					if s <= color[i][-1]:
						indi=i
						break
				indi+=1
				tab_start+='''<td style="font-size:11px;padding:2px;background-color:hsl(%d'''%(col_ratio*indi)+''', 100%, 50%);">'''
				tab_start+='''%r</td>'''%(s)
			else:
				indi = 1
				s=matrice[x,y]
				for i in range(len(color)):
					if s <= color[i][-1]:
						indi=i
						break
				indi+=1
				tab_start+='''<td style="font-size:11px;padding:2px;background-color:hsl(%d'''%(col_ratio*indi)+''', 100%, 50%);">'''
				tab_start+='''%r</td>'''%(s)
		tab_start+='''<td>%s</td>'''%(x)
		tab_start+='''</tr><tr>'''
	for x in g1:
		tab_start+='''<td valign="top" style="font-size:11px;">'''
		for el in range(len(x)):
			if el == len(x):
				tab_start+='''%s</td>'''%(x[el])
			else:
				tab_start+='''%s<br/>'''%(x[el])
	tab_start+=tab_end
	write_file('out_mat.html',tab_start)


#<td valign="top" style="font-size:11px;">c<br/>o<br/>r<br/>p<br/>u<br/>s<br/>_<br/>l<br/>t<br/>a<br/>l<br/>/<br/>a<br/>t<br/>p<br/>1<br/>-<br/>2<br/>/<br/>b<br/>a<br/#>s<br/>e<br/>.<br/>a<br/>l<br/>l</td>


#####mediane=len(l)/2#####


if __name__ == "__main__":
	folder=sys.argv[1]
	dis_type = sys.argv[2]
	moy_b = sys.argv[3]
	matrice=matrice_dist(folder)
	g1=[]
	g2=[]
	res=[]
	for d1,d2 in matrice:
		if d1 not in g1:
			g1.append(d1)
		elif d2 not in g2:
			g2.append(d2)
	z=endo_min(g1,g2,matrice,res,dis_type)
	f=entangled_mean(z,int(moy_b))
	g2 = g1 # Pour que les groupe soit pariel pour pouvoir bien les representer
	affichage(g1,g2,matrice,z,f)
	





