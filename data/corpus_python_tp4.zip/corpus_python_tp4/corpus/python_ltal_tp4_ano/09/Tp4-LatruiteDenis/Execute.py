# -*- coding: utf-8 -*-
import re
import sys
import glob
import pickle
import zlib
from decimal import *

def purge(p):#Ici, on nettoye le fichier lu précédement des balises genantes.
    pattern5=re.compile(u"[ ]+")#Enleve les espaces en trop
    p=pattern5.sub(u" ",p)
    p = re.sub(u'&nbsp;', ' ', p)#Enleve &nbsp; qui du codage et non du texte a traiter
    p=re.sub(u'&#8364;', ' ', p)#De même
    p=re.sub(u'&#8217;', ' ', p)#De même
    pattern4=re.compile(u"\\n")#Enleve les sauts de ligne(remplacé par un espace)
    p=pattern4.sub(u" ",p)
    pattern2=re.compile(u"<style.+?</style>")#Enleve les balise style.
    p=pattern2.sub(u" ",p)
    pattern2=re.compile(u"<script.+?</script>")#Même methode
    p=pattern2.sub(u" ",p)
    pattern2=re.compile(u"<noembed.+?</noembed>")#Même methode
    p=pattern2.sub(u" ",p)
    pattern2=re.compile(u"<select.+?</select>")#Même methode
    p=pattern2.sub(u" ",p)
    pattern3=re.compile(u"<nos[^(noscript>)]+noscript>")#Même methode
    p=pattern3.sub(u" ",p)
    pattern2=re.compile(u"<code>.+?</code>")#Même methode
    p=pattern2.sub(u" ",p)
    pattern=re.compile(u"<!--.+?-->")#Même methode
    p=pattern.sub(u" ",p)
    pattern=re.compile(u"<[^>]+>")#Même methode
    p=pattern.sub(u" ",p)
    
    pattern5=re.compile(u"[ ]+")#Verifie une derniere fois qu'il n'y a pas trop d'espace(en ayant rajouté...)
    p=pattern5.sub(u" ",p)   
    return p
    
def decode(fichier):#Lire le fichier puis l'encodé en unicode a partir de l'encoding trouvé.
    s=open(fichier,"r")
    encodagedebase="ISO-8859-1"#Je prend arbitrairement cette ecodage pour base.
    p=s.read()
    try:
		y=re.search(u"charset=[A-Za-z0-9-]+",p).group()#Cherche quelque chose ayant "charset=" et d'autre caractere aprés.
		if re.search(u"[A-Za-z0-9-]+$",str(y)):
			u=re.search(u"[A-Za-z0-9-]+$",str(y)).group()#Ici,on elimine "charset="
			encodagedebase=str(u)#On change l'encodage de base par l'encodage nouvellement trouvé.
		p=unicode(p,encodagedebase)
		s.close()
		p=purge(p)
		return p
    except:
		s.close()
		return p
    
def decode1(fichier):#Lire le fichier puis l'encodé en unicode a partir de l'encoding trouvé.
    s=open(fichier,"r")
    p=s.read()
    s.close()
    return p

def creerhtml(listedesfichier,moyenne,fichier):#Creer un fichier html à partir d'une liste.
    f=open(fichier,"w")
    couleur=120/(len(moyenne)+1)
    moyenne.sort()
    n='''
    <html>
        <head>
          <meta http-equiv="Content-Type"
                content="text/html; charset=UTF-8">
          <title>Titre</title>
        </head>
    <body>
  '''
    s = '''
    </body>
  </html>
  '''
    f.write(n)
    f.write('<table style="collapse:collapse;" cellspacing="0">')
    
    for j in listedesfichier:
		f.write('<tr>')
		
		for x in listedesfichier:
			f.write('<td style="font-size:13px;padding:2px;background-color:hsl(')
			u=0
			while distance_info(decode(j), decode(x))>moyenne[u]:
				u=u+1
				if u>len(moyenne)-1:
					break
			f.write(str(couleur*(u)))
			f.write(', 100%, 50%);">')

			f.write(str(distance_info(decode(j), decode(x))))
			f.write('</td>')
		f.write('<td>')
		f.write(j)
		f.write('</td>')
		f.write('</tr>')
	
    f.write('<tr>')
    for j in listedesfichier:
		f.write('<td valign="top" style="font-size:11px;">')
		for u in j:
			f.write(str(u))
			f.write("</br>")
		f.write('</td>')
    f.write('</tr>')
    f.write(s)
    f.close()
     
def distance_info(text1, text2):#0=identique 1=totallement different
    t12 = text1 + text2
    if str(text1)==str(text2):
		return 0
    else:
		c_t1  = float(len(zlib.compress(text1, zlib.Z_BEST_COMPRESSION)))
		c_t2  = float(len(zlib.compress(text2, zlib.Z_BEST_COMPRESSION)))
		c_t12 = float(len(zlib.compress(t12, zlib.Z_BEST_COMPRESSION)))
		distance =  1 - ((c_t1 + c_t2) - c_t12) / max(c_t1,c_t2)
		distance=Decimal(distance)
		return distance.quantize(Decimal('.01'), rounding=ROUND_HALF_UP)
		
		
def calculalldistance(listedesfichier):
	dico={}
	for x in listedesfichier:
		for y in listedesfichier:
			if y>x:
				dico[str((x,y))]=distance_info(decode(x), decode(y))
	return dico
		
def moyenne_enboiter(listedescle,nbclasse):
	listemoy=[]
	while nbclasse>0:
		if listemoy==[]:
			l=[dicodistance[x] for x in listedescle]
			
			moy=sum(l)/len(l)
	
			listemoy=listemoy+[moy]
			nbclasse-=1
			l=[dicodistance[x] for x in listedescle if dicodistance[x]>=listemoy[-1]]
			
			moy=sum(l)/len(l)
		
			listemoy=listemoy+[moy]
			l=[dicodistance[x] for x in listedescle if dicodistance[x]<listemoy[-2]]
		
			moy=sum(l)/len(l)
		
			listemoy=listemoy+[moy]
			nbclasse-=1
		else:
			l=[dicodistance[x] for x in listedescle if dicodistance[x]>=listemoy[-2]]
			
			moy=sum(l)/len(l)
		
			listemoy=listemoy+[moy]
			l=[dicodistance[x] for x in listedescle if dicodistance[x]<listemoy[-2]]
			
			moy=sum(l)/len(l)
			
			listemoy=listemoy+[moy]
			nbclasse-=1
	return listemoy
	

def dendromoy(l):
	u=[]
	bonneliste=[]
	for x in l:
		g=[]
		for y in l:
			g=g+[distance_info(decode(x), decode(y))]
		u=u+[(sum(g)/len(g)).quantize(Decimal('.01'), rounding=ROUND_HALF_UP)]
	while u!=[]:
		plusgrand=1
		comp=0
		ok=0
		for x in u:
			if x<plusgrand:
				plusgrand=x
				ok=comp
			comp+=1
		u.remove(plusgrand)
		bonneliste=bonneliste+[l[ok]]
		l.remove(l[ok])
	return bonneliste
			
def dendromax(l):
	u=[]
	bonneliste=[]
	for x in l:
		g=[]
		for y in l:
			g=g+[distance_info(decode(x), decode(y))]
		k=0
		for c in g:
			if c>k:
				k=c
		u=u+[k]
	while u!=[]:
		plusgrand=1
		comp=0
		ok=0
		for x in u:
			if x<plusgrand:
				plusgrand=x
				ok=comp
			comp+=1
		u.remove(plusgrand)
		bonneliste=bonneliste+[l[ok]]
		l.remove(l[ok])
	return bonneliste			
			
def dendromin(l):
	u=[]
	bonneliste=[]
	for x in l:
		g=[]
		for y in l:
			g=g+[distance_info(decode(x), decode(y))]
		k=1
		for c in g:
			if c<k and c!=0:
				k=c
		u=u+[k]
	while u!=[]:
		plusgrand=1
		comp=0
		ok=0
		for x in u:
			if x<plusgrand:
				plusgrand=x
				ok=comp
			comp+=1
		u.remove(plusgrand)
		bonneliste=bonneliste+[l[ok]]
		l.remove(l[ok])
	return bonneliste	

if __name__=='__main__' :
	listedesfichier=[]
	corpus = sys.argv[1]
	distance = sys.argv[2]
	nbclasse = int (sys.argv[3])

	
		
	for fic1 in glob.glob("%s*"%(corpus)):
		listedesfichier=listedesfichier+[fic1]
		
	dicodistance=calculalldistance(listedesfichier)
	listedescle=dicodistance.keys()
	moyenne=moyenne_enboiter(listedescle,nbclasse)
	if str(distance)== "average-linkage":
		ok = dendromoy(listedesfichier)
		creerhtml(ok,moyenne,"moyenne.html")
	if str(distance)== "single-linkage":
		ok = dendromin(listedesfichier)
		creerhtml(ok,moyenne,"min.html")
	if str(distance)== "complete-linkage":
		ok = dendromax(listedesfichier)
		creerhtml(ok,moyenne,"max.html")
