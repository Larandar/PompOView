# -*- coding: UTF-8 -*-

import re
import os
import sys
import string
import glob
import zlib
import math
import webbrowser

def LireFichierTexte(nom_fichier_complet):
  ofi = open(nom_fichier_complet, 'r')   
  chaine = ofi.read()
  ofi.close()
  return chaine
  
def distance(d1,d2):
  fic1=LireFichierTexte(d1)
  fic2=LireFichierTexte(d2)
  fic3=concat(d1,d2)
  outdata1 = zlib.compress(fic1)
  outdata2 = zlib.compress(fic2)
  outdata3 = zlib.compress(fic3)

  res= 1-float((len(outdata1) + len(outdata2) - len(outdata3)))/float(max(len(outdata1),len(outdata2)))
  res=round(res,2)
  return res  

def concat(d1,d2):
  ch1=LireFichierTexte(d1)
  ch2=LireFichierTexte(d2)
  ch1=ch1+ch2
  return ch1

## Créer une liste des distances entre tous les fichiers du dossier à tester ##
def listerDistFichier(path):
  fichiers = []
  res = []
  for nm in glob.glob(path):
    fichiers += [nm]
  for i in fichiers:
    a = []
    for j in fichiers:
      a.append(((i, j), distance(i, j)))
    res.append(a)
  return res

def minDendrogramme(liste):
  list_mat = []
  prog="|"
  for i in range(0, len(liste)):
    for j in range(i+1, len(liste[i])):
      list_mat.append((liste[i][j]))
  while len(list_mat)!=1:
    n, m = 1, 0
    x, y = 0, 0
    for i in range(len(list_mat)):
      for j in range(len(list_mat)):
        if i!=j:
          if abs(float(list_mat[i][1]) - float(list_mat[j][1])) < n:
            m = min(list_mat[i][1], list_mat[j][1])
            n = abs(float(list_mat[i][1]) - float(list_mat[j][1]))
            x = i
            y = j
    list_mat[x] = (list_mat[x], list_mat[y]), m
    list_mat.__delitem__(y)
    if prog=="|":
      prog="/"
    elif prog=="/":
      prog="--"
    elif prog=="--":
      prog="\ "
    elif prog=="\ ":
      prog="|"
    os.system("clear")
    print "Travail en cours... 20% Construction dendrogramme en cours: "+str(prog)+" "    
  return list_mat


def maxDendrogramme(liste):
  list_mat = []
  prog="|"
  for i in range(0, len(liste)):
    for j in range(i+1, len(liste[i])):
      list_mat.append((liste[i][j]))
  while len(list_mat)!=1:
    n, m = 1, 0
    x, y = 0, 0
    for i in range(0, len(list_mat)):
      for j in range(0, len(list_mat)):
        if abs(float(list_mat[i][1]) - float(list_mat[j][1])) < n and i!=j:
          m = max(list_mat[i][1], list_mat[j][1])
          n = abs(float(list_mat[i][1]) - float(list_mat[j][1]))
          x = i
          y = j

    list_mat[x] = (list_mat[x], list_mat[y]), m
    list_mat.__delitem__(y)
    if prog=="|":
      prog="/"
    elif prog=="/":
      prog="--"
    elif prog=="--":
      prog="\ "
    elif prog=="\ ":
      prog="|"
    os.system("clear")
    print "Travail en cours... 20% Construction dendrogramme en cours: "+str(prog)+" "
  return list_mat

def moy(a, b):
  return(float((a+b))/float(2))

def moyDendrogramme(liste):
  list_mat = []
  prog="|"
  for i in range(0, len(liste)):
    for j in range(i+1, len(liste[i])):
      list_mat.append((liste[i][j]))
  while len(list_mat)!=1:
    n, m = 1, 0
    x, y = 0, 0
    for i in range(len(list_mat)):
      for j in range(len(list_mat)):
        if abs(float(list_mat[i][1]) - float(list_mat[j][1])) < n and i!=j:
          n = abs(float(list_mat[i][1]) - float(list_mat[j][1]))
          m = moy(list_mat[i][1], list_mat[j][1])
          x = i
          y = j
    list_mat[x] = (list_mat[x], list_mat[y]), m
    list_mat.__delitem__(y)
    if prog=="|":
      prog="/"
    elif prog=="/":
      prog="--"
    elif prog=="--":
      prog="\ "
    elif prog=="\ ":
      prog="|"
    os.system("clear")
    print "Travail en cours... 20% Construction dendrogramme en cours: "+str(prog)+" "
  return list_mat


def profDendro(dendro, liste):
  if type(dendro)==tuple:
    if type(dendro[0][0])==str:
      liste.append(((dendro[0][0], dendro[0][1]), dendro[1]))
      return liste
    else:
      for i in range(len(dendro[0])):
        liste = profDendro(dendro[0][i], liste)
  elif type(dendro)==list:
    liste = profDendro(dendro[0], liste)
  return liste

def creerMatrice(dendro, dist_corpus):
  dist = len(dist_corpus)
  matrice = [0] * (dist+1)
  for i in range(0, dist+1):
     matrice[i] = [0] * (dist+1)  
  n = 0
  list_fin = []
  matr = []
  for i in range(len(dendro)):
    if list_fin.__contains__(dendro[i][0][0])==False:
      list_fin.append(dendro[i][0][0])
      value = []
      for j in range(len(dendro)):
        if dendro[i][0][0]==dendro[j][0][0]:
          value.append(dendro[j][1])
      matr.append((list_fin[len(list_fin)-1], value))
  for i in range(len(dendro)):
    if list_fin.__contains__(dendro[i][0][1])==False:
      nomFichier = dendro[i][0][1]
  for i in matr:
    rang = dist - len(i[1])
    n = 0
    for j in range(len(i[1])):
      matrice[rang][dist-j-1] = i[1][n]
      matrice[dist-j][rang-1] = i[1][n]
      n+=1
    matrice[rang][dist] = i[0]
    matrice[0][rang-1] = i[0]
  matrice[0][dist-1] = nomFichier
  matrice[dist][dist] = nomFichier
  return matrice



def creerHTML(htmlFile, matrice):
	fich = open(htmlFile, "w")
	s = ''
	fich.write('<html><head></head><body><table style="font-size:10px;border:1px solid black;'+\
		'border-collapse:collapse;">')
	for i in range(1, len(matrice)):
	    fich.write('<tr height="5px">')
	    for j in range(len(matrice[i]) - 1):
	      if matrice[i][j] < 0.20:
	        c=0
              if matrice[i][j] >= 0.40 and matrice[i][j] < 0.60:
	        c=30
              if matrice[i][j] >= 0.60 and matrice[i][j] < 0.80: 
	        c=60
	      if matrice[i][j] >= 0.80 and matrice[i][j] < 0.90 : 
	        c=90
	      if matrice[i][j] >= 0.90: 
	        c=120
	      if matrice[i][j] == 1: 
	        c=150
	      s += "<td width='5px' height='5px' style='padding:2px;border:1px solid black;background-color:hsl("+str(c)+" , 100%, 50%);text-align:center;'>"+str(matrice[i][j])+"</td>"
	    r=''
            fr=matrice[i][len(matrice)-1].split('/')
            r+=fr[-1]
	    s+='<td><p style="font-size:9px;">'+(r)+'</p></td>'
	    fich.write(s)
	    s = ''
	    fich.write('</tr>')
	fich.write('<tr>')
	for i in range(len(matrice) - 1):
	    r = '<p style="font-size:10px;">'
            fr=matrice[0][i].split('/')
            r+=fr[-1]
            r+='</p>'
	    q = '<td>'+r+'</td>'
	    fich.write(q)
	fich.write('</tr></table>')
	fich.write('</body></html>')
	fich.close()

## Analyse de la requète utilisateur, ajout d'une progression en cas de long corpus, et ouverture 
## du résultat dans le navigateur internet.

if __name__=="__main__":
	if sys.argv[2] == "min":
	   print "Travail en cours... 0% Veuillez patientez..."
	   l = listerDistFichier(sys.argv[1]+"/*")
	   print "Travail en cours... 20% Veuillez patientez..."
	   p=minDendrogramme(l)
	   
	   
	if sys.argv[2] == "moy":
	   print "Travail en cours... 0% Veuillez patientez..."
	   l = listerDistFichier(sys.argv[1]+"/*")
	   print "Travail en cours... 20% Veuillez patientez..."
	   p=moyDendrogramme(l)
	if sys.argv[2] == "max":
	   print "Travail en cours... 0% Veuillez patientez..."
	   l = listerDistFichier(sys.argv[1]+"/*")
	   print "Travail en cours... 20% Veuillez patientez..."
	   p=maxDendrogramme(l)

	print "Travail en cours... 60% Veuillez patientez..."
        x=profDendro(p,[])
	print "Travail en cours... 70% Veuillez patientez..."
	dm = creerMatrice(x,l)
	print "Travail en cours... 90% Veuillez patientez..."
	creerHTML("res_"+sys.argv[2]+"_"+sys.argv[1]+".html",dm)
	print "Travail en cours: 100% Terminé avec succès!"
	print "Ouverture du fichier dans un navigateur.."
	webbrowser.open_new("res_"+sys.argv[2]+"_"+sys.argv[1]+".html")

