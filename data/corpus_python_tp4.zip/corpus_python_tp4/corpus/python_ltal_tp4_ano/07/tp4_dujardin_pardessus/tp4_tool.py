import re, string, os, sys


def lireFichier(fichier):
    f = open(fichier,'r')
    open_fichier = f.read()
    f.close()
    return open_fichier

def ecrireFichier(fichier, chaine):
    f = open(fichier, 'w')
    f.write(chaine)
    f.close

def preparerFichier(fichier):
    # ouvrir le fichier
    lire_ficher_html = lireFichier(fichier)
    encoding_original = 'utf-8'
    # le passe en unicode
    html_to_unicode = unicode(lire_ficher_html, encoding_original, 'replace')
    # le nettoie
    list_word_clean = clean_unicode_html(html_to_unicode)
    return list_word_clean

#____________________________________________________________________________________________________

def get_listeMots(html_unicode):
    html_unicode = re.sub(u'<[^>]+>', u'#', html_unicode)
    pattern_word = u'[^\s\'".?;,:!\(\)\[\]\|]+'
    pattern_word_compiled = re.compile(pattern_word)
    listeMots = pattern_word_compiled.findall(html_unicode)
    return listeMots

def get_dicoMots(liste):
    dico={}
    for x in liste:
        if dico.has_key(x):
            dico[x]+=1
        else:
            dico[x]=1
    return dico

def fusion(dico1,dico2):
    for x,y in dico2.iteritems():
        if x in dico1:
            dico1[x]+=y
        else:
            dico1[x]=y
    return dico1

def trigram(ch_unicode):
    n=3
    liste_ngram =[]
    for i in xrange(len(ch_unicode)-n):
        ngram = ch_unicode[i:i+n]
        liste_ngram.append(ngram)
    return liste_ngram

def suffixe(ch_unicode):
    n=3
    liste_suffixe=[]
    liste_ch=ch_unicode.split()
    for i in xrange(len(liste_ch)):
        liste_suffixe.append(liste_ch[i][-n:])
    return liste_suffixe



#____________________________________________________________________________________________________


def clean_unicode_html(source_unicode) :
    clean_html = re.sub(u'&nbsp;', ' ', source_unicode)
    clean_html = re.sub(u'[\s]+', u' ', clean_html)

    pattern1 = re.compile(u'<script.+?</script>', re.I | re.M)
    clean_html = pattern1.sub(u'', clean_html)

    pattern2 = re.compile(u'<!\-\-.+?\-\->', re.M)
    clean_html = pattern2.sub(u'', clean_html)

    pattern3 = re.compile(u'<select.+?</select>', re.I | re.M)
    clean_html = pattern3.sub(u'', clean_html)

    pattern4 = re.compile(u'<style.+?</style>', re.I | re.M)
    clean_html = pattern4.sub(u'', clean_html)

    clean_html = re.sub(u'(?:&gt;|&lt;)', u' ', clean_html)

    pattern5 = re.compile(u'[\s]*</*[^>]+/*>[\s]*', re.I | re.M)
    clean_html = pattern5.sub(u' ', clean_html)

    pattern6 = re.compile(u'\s[#\s]+', re.I | re.M)
    clean_html = pattern6.sub(u' ', clean_html)

    pattern7 = re.compile(u'<ul.+?</ul>', re.I | re.M)
    clean_html = pattern7.sub(u'', clean_html)

    pattern8 = re.compile(u'<form.+?</form>', re.I | re.M)
    clean_html = pattern8.sub(u'', clean_html)

    pattern9 = re.compile(u'<a.+?</a>', re.I | re.M)
    clean_html = pattern9.sub(u'', clean_html)
  
    return clean_html
