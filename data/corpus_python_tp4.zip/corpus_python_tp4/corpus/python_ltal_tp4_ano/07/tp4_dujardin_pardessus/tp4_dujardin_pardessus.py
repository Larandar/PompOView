import zlib
import glob

import tp4_tool as tool

# calcule la distance informelle entre deux textes
def distance_info (text1, text2):
    t12 = text1 + text2
    c_t1  = float(len(zlib.compress(text1, zlib.Z_BEST_COMPRESSION)))
    c_t2  = float(len(zlib.compress(text2, zlib.Z_BEST_COMPRESSION)))
    c_t12 = float(len(zlib.compress(t12, zlib.Z_BEST_COMPRESSION)))

    distance =  1 - ((c_t1 + c_t2) - c_t12) / max(c_t1,c_t2)
    return distance



# creer la matrice entre deux textes et leur distance
def generer_matrice (corpus):
    liste_chemin = glob.glob('%s*'%(corpus))
    m = {}
    for i,f1 in enumerate(liste_chemin):
        for j,f2 in enumerate(liste_chemin):
            if i<j:
                continue
            if i == j:
                pass
                #m[(f1,f2)] = 0
            else:
                m[(f1,f2)]= m[(f1,f2)]= distance_info(f1,f2)
    return m


# calcul la moyenne emboitee d'une liste
def moyenne_emboitee (liste,nombre_iterration):
    lg = []
    ld = []
    if nombre_iterration<=0:
        return [liste]
    
    else:
        moyenne = sum(liste)/len(liste)
        for nb in liste:
            if nb<=moyenne:
                lg.append(nb)
            else:
                ld.append(nb)
    return moyenne_emboitee (lg,nombre_iterration-1), moyenne_emboitee (ld,nombre_iterration-1)





def htmlcolor(l,fichier):
    htmlres = []
    
    htmlres.append(u'<table style="collapse:collapse;" cellspacing="0">\n<tr>')

    for a in l:
        htmlres.append(u'<tr>\n')  # On commence une nouvelle ligne du tableau
        for dif in a:
            color=dif*120
            htmlres.append(u'<td style="font-size:11px;padding:2px;background-color:hsl(%s , 100%%, 50%%);"> %s </td>'  %(color, dif)) #On ajoute les cases avec leur couleurs
        htmlres.append(u'\n </tr>')  # On termine la ligne

    
    htmlres = ''.join(htmlres)
    tool.ecrireFichier(fichier + '.resultats.html',htmlres)  # On ecrit le fichier 




# calcul la distance minimum entre deux textes dans la matrice
def distance_minimum(matrice):
    groupe = ()
    liste_val = matrice.values()
    for x in matrice:
        if matrice[x] == min(liste_val) :
            groupe = x,min(liste_val)
    return groupe


# creation du dendrogramme sous forme d'un dictionnaire
def dendrogramme(corpus):
    dendro = {}
    matrice = generer_matrice(corpus)
    liste_chemin = glob.glob('%s*'%(corpus))
    nb_docs = liste_chemin
    moyenne = 0
    # car a chaque passage, on efface un chemin de la liste
    while len(nb_docs) != 0:
        # afin d'obtenir les deux documents les plus proche avec leur distance
        groupe = distance_minimum(matrice)
        del matrice[groupe[0]]
        # afin de tester chaque chemin
        for chemin in liste_chemin:
            # test si les deux chemins avec la plus courte distance sont deja dans le dendrogramme
            if groupe[0][0] in dendro and groupe[0][1] in dendro:
                if (groupe[0][1],chemin) in matrice:
                    moyenne = (matrice[(groupe[0][0], chemin)] + matrice[(groupe[0][1], chemin)]) / float(2)
                    del matrice[(groupe[0][0], chemin)]
                    del matrice[(groupe[0][1], chemin)]
                    matrice[((groupe[0][0], groupe[0][1]), chemin)]= moyenne
                for tuuple in xrange(len(dendro)):
                    if dendro[tuuple] == groupe[0][0] or dendro[tuuple] == groupe[0][1]:
                        del dendro[tuuple]
                        
            # test si le premier chemin avec la plus courte distance est deja dans le dendrogramme
            elif groupe[0][0] in dendro:
                if (chemin, groupe[0][1]) in matrice:
                    moyenne = (matrice[(groupe[0][0], chemin)] + matrice[(chemin, groupe[0][1])]) / float(2)
                    del matrice[(groupe[0][0], chemin)]
                    del matrice[(chemin, groupe[0][1])]
                    for tuuple in dendro:
                        if (tuuple, groupe[0][0]) in matrice:
                            del matrice[(tuuple, groupe[0][0])]
                        if (tuuple, groupe[0][1]) in matrice:
                            del matrice[(tuuple, groupe[0][1])]
                    matrice[((groupe[0][0], groupe[0][1]), chemin)]= moyenne
                elif (groupe[0][1], chemin) in matrice:
                    moyenne = (matrice[(groupe[0][0], chemin)] + matrice[(groupe[0][1], chemin)]) / float(2)
                    del matrice[(groupe[0][0], chemin)]
                    del matrice[(groupe[0][1], chemin)]
                    for tuuple in dendro:
                        if (tuuple, groupe[0][0]) in matrice:
                            del matrice[(tuuple, groupe[0][0])]
                        if (tuuple, groupe[0][1]) in matrice:
                            del matrice[(tuuple, groupe[0][1])]
                    matrice[((groupe[0][0], groupe[0][1]), chemin)]= moyenne

            # test si le second chemin avec la plus courte distance est deja dans le dendrogramme
            elif groupe[0][1] in dendro:
                if (groupe[0][0], chemin) in matrice:
                    moyenne = (matrice[(groupe[0][0], chemin)] + matrice[(groupe[0][1], chemin)]) / float(2)
                    del matrice[(groupe[0][0], chemin)]
                    del matrice[(groupe[0][1], chemin)]
                    for tuuple in dendro:
                        if (tuuple, groupe[0][0]) in matrice:
                            del matrice[(tuuple, groupe[0][0])]
                        if (tuuple, groupe[0][1]) in matrice:
                            del matrice[(tuuple, groupe[0][1])]               
                    matrice[((groupe[0][0], groupe[0][1]), chemin)]= moyenne
                elif (chemin,groupe[0][0]) in matrice:
                    moyenne = (matrice[(chemin,groupe[0][0])] + matrice[(groupe[0][1], chemin)]) / float(2)
                    del matrice[(chemin,groupe[0][0])]
                    del matrice[(groupe[0][1], chemin)]
                    for tuuple in dendro:
                        if (tuuple, groupe[0][0]) in matrice:
                            del matrice[(tuuple, groupe[0][0])]
                        if (tuuple, groupe[0][1]) in matrice:
                            del matrice[(tuuple, groupe[0][1])]               
                    matrice[((groupe[0][0], groupe[0][1]), chemin)]= moyenne

                        
                
            # test (chemin, chemin 1) existe
            elif (chemin,groupe[0][0]) in matrice:
                
                # test (chemin, chemin 2) existe
                if (chemin,groupe[0][1]) in matrice:
                    moyenne = (matrice[(chemin,groupe[0][0])] + matrice[(chemin,groupe[0][1])]) / float(2)
                    del matrice[(chemin,groupe[0][0])]
                    del matrice[(chemin,groupe[0][1])]
                    for tuuple in dendro:
                        if (tuuple,groupe[0][0]) in matrice:
                            del matrice[(tuuple,groupe[0][0])]
                        if (tuuple,groupe[0][1]) in matrice:
                            del matrice[(tuuple,groupe[0][1])]  
                # sinon test (chemin 2, chemin) existe
                elif (groupe[0][1],chemin) in matrice:
                    moyenne = (matrice[(chemin,groupe[0][0])] + matrice[(groupe[0][1],chemin)]) / float(2)
                    del matrice[(chemin,groupe[0][0])]
                    del matrice[(groupe[0][1],chemin)]
                    for tuuple in dendro:
                        if (tuuple,groupe[0][0]) in matrice:
                            del matrice[(tuuple,groupe[0][0])]
                        if (tuuple,groupe[0][1]) in matrice:
                            del matrice[(tuuple,groupe[0][1])]

                    
            # sinon test (chemin 1, chemin) existe                
            elif (groupe[0][0], chemin) in matrice:
                
                # test (chemin, chemin 2) existe
                if (chemin,groupe[0][1]) in matrice:
                    moyenne = (matrice[(groupe[0][0],chemin)] + matrice[(chemin,groupe[0][1])]) / float(2)
                    del matrice[(groupe[0][0],chemin)]
                    del matrice[(chemin,groupe[0][1])]
                    for tuuple in dendro:
                        if (tuuple,groupe[0][0]) in matrice:
                            del matrice[(tuuple,groupe[0][0])]
                        if (tuuple,groupe[0][1]) in matrice:
                            del matrice[(tuuple,groupe[0][1])]
                # sinon test (chemin 2, chemin) existe
                elif (groupe[0][1],chemin) in matrice:
                    moyenne = (matrice[(groupe[0][0],chemin)] + matrice[(groupe[0][1],chemin)]) / float(2)
                    del matrice[(groupe[0][0],chemin)]
                    del matrice[(groupe[0][1],chemin)]
                    for tuuple in dendro:
                        if (tuuple,groupe[0][0]) in matrice:
                            del matrice[(tuuple,groupe[0][0])]
                        if (tuuple,groupe[0][1]) in matrice:
                            del matrice[(tuuple,groupe[0][1])]
                matrice[((groupe[0][0], groupe[0][1]), chemin)] = moyenne
                
        # permet de supprimer le chemin utilis�
        for j in range(len(nb_docs)):
            if nb_docs[j] == groupe[0][0] or nb_docs[j] == groupe[0][1]:
                del nb_docs[j]
                break
        for i in dendro:
            if i == groupe[0]:
                del dendro
                break
        dendro[groupe[0]] = groupe[1]
    return dendro
