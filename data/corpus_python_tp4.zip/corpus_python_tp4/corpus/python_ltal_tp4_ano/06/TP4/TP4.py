################ TP4 ##############
import zlib
import glob
import os
import sys





def distance( text1, text2):
    t12 = text1 + text2
    c_t1  = float(len(zlib.compress(text1, zlib.Z_BEST_COMPRESSION)))
    c_t2  = float(len(zlib.compress(text2, zlib.Z_BEST_COMPRESSION)))
    c_t12 = float(len(zlib.compress(t12, zlib.Z_BEST_COMPRESSION)))

    distance =  1 - ((c_t1 + c_t2) - c_t12) / max(c_t1,c_t2)
    return distance







def matrice(path):
    m={}
    expr="%s*"%(path)
    list_path_files=glob.glob(expr)
    

    for i, f1 in enumerate(list_path_files):
        
        for j, f2 in enumerate(list_path_files):
            
                m[(i,j)]= distance(f1,f2)
    return m

def moyenne(l):  
    l_g=[]
    l_d=[]
    
    if l!=[]:       
    
        moy= sum(l)/len(l)
        for e in l:
            if e <= moy :
                l_g.append(e)

            else :                
                l_d.append(e)
                
        if len(l_d)==0:
            return [l_g]
        if len(l_g)==0:
            return [l_d]
               
        return l_g,l_d


def gener_liste_interval(m,nb_i):
    l=m.values()
    l_inter=[]
    l_inter2=[]
    l_res=moyenne(l)
    for i in xrange(nb_i-1):
        l_inter=l_res
        l_res=[]
        for i in xrange(len(l_inter)):
            l_inter2=moyenne(l_inter[i])
            l_res+=l_inter2
          
    return l_res

def dico_interval(liste_interval):
    pas=0
    if len(liste_interval)!=0:
        pas=120/len(liste_interval)
        
    dico={(0,min(liste_interval[0])):0}
    couleur=0
    for i in xrange(len(liste_interval)):
        couleur=couleur+pas
        dico[(min(liste_interval[i]),max(liste_interval[i]))]=couleur
    dico[max(liste_interval[-1]),1]= 120
    
    return dico

        

def return_tuple(tupl):
    return tupl[0],tupl[1]




def creer_matrice_html(path,nb_i):
    s1="""<tr><td>  </td>"""
    s2=""
    distance=''
    mat=matrice(path)
    liste_interval=[]
    liste_interval+=gener_liste_interval(mat,nb_i)
    couleur="0"
    dico_interv=dico_interval(liste_interval)
    l_test_interv=dico_interv.keys()
    
    for i in xrange(len(glob.glob(path))):
        s1+="""<th style="background-color:hsl(25, 100%, 97%);">  doc """+str(i+1)+"""  </th>"""
    s1+="</tr>"

    
    for j in xrange(len(glob.glob(path))):
        s2+="""<tr><th style="background-color:hsl(25, 100%, 97%);">  doc """+str(j+1)+"""  </th>"""
        for k in xrange(len(glob.glob(path))):
            
            for tupl in  l_test_interv:
                dis=mat[(j,k)]
                
                t=return_tuple(tupl)         
                
                
                
                if  t[0]< dis <= t[1]:
                        
                    
                    couleur=str(dico_interv[tupl])
                        
                
                        
                    
                                
            distance= str(mat[(j,k)])
            s2+="""<th style="background-color:hsl("""+couleur+""", 100%, 50%);">  """+distance[:4]+"""  </th>"""
            
        s2+="</tr>"
    
    s3="""<table BORDER=1>%s</table>"""%(s1+s2)
    f=open("matrice_hs.html",'w')
    f.write(s3)
    
    
    f.close

   

