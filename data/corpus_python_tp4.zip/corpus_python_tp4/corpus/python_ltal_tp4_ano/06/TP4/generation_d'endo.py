# -*- coding: utf-8 -*-
################### TP-4 #####################



import zlib
import glob




def main(path):
    mat, nb_docs = matrice(path)
    liste_dendo = creer_couples(mat, nb_docs)
    print liste_dendo



def distance( text1, text2):
    t12 = text1 + text2
    c_t1  = float(len(zlib.compress(text1, zlib.Z_BEST_COMPRESSION)))
    c_t2  = float(len(zlib.compress(text2, zlib.Z_BEST_COMPRESSION)))
    c_t12 = float(len(zlib.compress(t12, zlib.Z_BEST_COMPRESSION)))

    distance =  1 - ((c_t1 + c_t2) - c_t12) / max(c_t1,c_t2)
    return distance


def matrice(path):
    m={}
    expr="%s*"%(path)
    list_path_files=glob.glob(expr)
    nb_docs = len(list_path_files)

    for i, f1 in enumerate(list_path_files):
        
        for j, f2 in enumerate(list_path_files):
            if i<j :
                m[(i,j)]= distance(f1,f2)
    return m, nb_docs

def moyenn_emb(l, nb_i):
    moy = sum(l)/len(l)

def cherch_dist_min(matrice):
    groupe = ()
    li = matrice.values()
    for i in matrice:
        if matrice[i] == min(li) :
            groupe = i
    return groupe

def creer_couples(matrice, nb_docs):
    liste_groupes = []
    fin = False
    l_docs = []
    l_gr = []
    for i in xrange(nb_docs):
        l_docs += [i]
    while fin != True:
        groupe = cherch_dist_min(matrice)
        liste_groupes+= [[groupe[0]], [groupe[1]]]
        del matrice[groupe]
        for j in l_docs:
            if groupe[0] in l_gr and groupe[1] in l_gr:
                if j < groupe[1]:
                    moyenne = (matrice[(groupe[0], j)] + matrice[(groupe[1], j)]) / float(2)
                    del matrice[(groupe[0], j)]
                    del matrice[(groupe[1], j)]
                    matrice[((groupe[0], groupe[1]), j)]= moyenne
                for i in xrange(len(l_gr)):
                    if l_gr[i] == groupe[0]:
                        del l_gr[i]
                for i in xrange(len(l_gr)):
                    if l_gr[i] == groupe[1]:
                        del l_gr[i]
            elif groupe[0] in l_gr:
                if j < groupe[1]:
                    moyenne = (matrice[(groupe[0], j)] + matrice[(j, groupe[1])]) / float(2)
                    del matrice[(groupe[0], j)]
                    del matrice[(j, groupe[1])]
                    for i in l_gr:
                        if (i, groupe[0]) in matrice:
                            del matrice[(i, groupe[0])]
                        if (i, groupe[1]) in matrice:
                            del matrice[(i, groupe[1])]
                    matrice[((groupe[0], groupe[1]), j)]= moyenne
                elif j != groupe[1]:
                    moyenne = (matrice[(groupe[0], j)] + matrice[(groupe[1], j)]) / float(2)
                    del matrice[(groupe[0], j)]
                    del matrice[(groupe[1], j)]
                    for i in l_gr:
                        if (i, groupe[0]) in matrice:
                            del matrice[(i, groupe[0])]
                        if (i, groupe[1]) in matrice:
                            del matrice[(i, groupe[1])]                   
                    matrice[((groupe[0], groupe[1]), j)]= moyenne
            elif j != groupe[0] and j != groupe[1]:
                if j < groupe[0]:
                        moyenne = (matrice[(j, groupe[0])] + matrice[(j, groupe[1])] ) / float(2)
                        del matrice[(j, groupe[0])]
                        del matrice[(j, groupe[1])]
                        for i in l_gr:
                            if (i, groupe[0]) in matrice:
                                del matrice[(i, groupe[0])]
                            if (i, groupe[1]) in matrice:
                                del matrice[(i, groupe[1])]  
                else:
                    if j<groupe[1]:
                        moyenne = (matrice[(groupe[0], j)] + matrice[(j, groupe[1])]) / float(2)
                        del matrice[(groupe[0], j)]
                        del matrice[(j, groupe[1])]
                        for i in l_gr:
                            if (i, groupe[0]) in matrice:
                                del matrice[(i, groupe[0])]
                            if (i, groupe[1]) in matrice:
                                del matrice[(i, groupe[1])]  
                    else:
                        moyenne = (matrice[(groupe[0], j)] + matrice[(groupe[1], j)]) / float(2)
                        del matrice[(groupe[0], j)]
                        del matrice[(groupe[1], j)]
                        for i in l_gr:
                            if (i, groupe[0]) in matrice:
                                del matrice[(i, groupe[0])]
                            if (i, groupe[1]) in matrice:
                                del matrice[i, (groupe[1])]  
                matrice[((groupe[0], groupe[1]), j)]= moyenne
            nb_docs -= 1
        for k in range(len(l_docs)):
            if l_docs[k] == groupe[0]:
                del l_docs[k]
                break
        for l in range(len(l_docs)):
            if l_docs[l] == groupe[1]:
                del l_docs[l]
                break
        for m in range(len(l_gr)):
            if l_gr[m] == groupe[0]:
                del l_gr[m]
                break
        l_gr += [(groupe[0], groupe[1])]
        if len(l_docs) == 0:
            fin = True
    return l_gr
        
        
        

        
main("docs_test/*")
  
