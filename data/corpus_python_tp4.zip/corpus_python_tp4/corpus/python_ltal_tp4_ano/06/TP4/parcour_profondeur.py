
# -*- coding: utf-8 -*-
l1 = [(1, (4, ((5, (6, 10)), 7))), (((3, 2), 9), (11, 8))]

def plus_longue_branche(dendo):
    while type(dendo) != int:
        if longueur_branche(dendo[0]) >= longueur_branche(dendo[1]):
            return "gauche"
        else:
            return "droite"
    return "fin"
        

def longueur_branche(dendo):
    if type(dendo)==int:
        return 1
    lg_br = longueur_branche(dendo[0]) + longueur_branche(dendo[1])
    return lg_br

def trouv_prem(dendo):
    chem = []
    while plus_longue_branche(dendo) != "fin":
        chem += [plus_longue_branche(dendo)]
        if plus_longue_branche(dendo) == "gauche":
            dendo = dendo[0]
        elif plus_longue_branche(dendo) == "droite":
            dendo = dendo[1]
    return chem

def ordonn_dendo(dendo):
    liste = []
    i = 0
    premier = []
    fin = False
    premier = trouv_prem(dendo)
    liste += [trouv_corresp(premier, dendo)]
    while len(premier) > 0:
        
        if premier[-1] == "gauche":
            del premier[-1]
            premier += ["droite"]
            if longueur_branche(trouv_corresp(premier, dendo)) > 1:
                liste += ordonn_dendo(trouv_corresp(premier, dendo))
            

        elif premier[-1] == "droite":
            del premier[-1]
            premier += ["gauche"]
            
            if longueur_branche(trouv_corresp(premier, dendo)) > 1:
                liste += ordonn_dendo(trouv_corresp(premier, dendo))
        if type(trouv_corresp(premier, dendo)) == int:
            liste += [trouv_corresp(premier, dendo)]
        del premier[-1]
     

        
        
    return liste

                    
def trouv_corresp(liste, dendo):
    for i in liste:
        if i == "gauche":
            dendo = dendo[0]
        elif i == "droite":
            dendo = dendo[1]
    return dendo
    










    
